-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2021 at 03:53 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `BookingID` int(2) NOT NULL,
  `EventName` varchar(100) NOT NULL,
  `EventDuration` varchar(100) NOT NULL,
  `EventLocation` varchar(100) NOT NULL,
  `ParticipantName` varchar(100) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`BookingID`, `EventName`, `EventDuration`, `EventLocation`, `ParticipantName`, `Status`) VALUES
(48, 'Episode 3 [The new chapter of life is drawn by me]', '12pm-2pm 2 hrs', 'Public to anyone on or off Facebook', 'Tomy22', 'Going');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `Name` varchar(500) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `location` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `ImageId` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Name`, `duration`, `location`, `description`, `ImageId`) VALUES
('40 Family Relations Rahman University College Buddhist Association 40th Anniversary Gala', '12pm-2pm 2 hrs', 'Tarc college, hall 2', 'Through the years of impermanence year after year, we have witnessed countless Laman\'s footsteps-the Buddhist Society has reached 40 years old! Over the past 40 years, the Buddhist Society has been like a home-it has brought together Raman students from all over Malaysia, and grows up with us, spending time at university full of joy, anger, sorrow and joy. Whether you are a current member of the Buddhist Society or already We sincerely invite you to attend the 40th Anniversary Celebration of the <<40. Jiayuan>> Buddhist Society for the former members who have graduated, and even the students who have not yet joined us. ', '612e4ebf00a6c.jpeg'),
('Episode 3 [The new chapter of life is drawn by me]', '12pm-2pm 2 hrs', 'Public to anyone on or off Facebook', 'Life is to bravely pick up a pen and draw boldly in one\'s own chapters of life! In the previous orientation party, unfortunately, due to time, we could not complete the program we arranged and so! This Thursday we have agreed that you will participate in the sequel of our orientation meeting-the third episode [the new chapter of life is drawn by me]. A series of team games will be held that evening‼ ️Before the end, there will be a few positive Buddha songs. Hear this, get interested! You can also participate outside the school.', '612e4d035fef3.jpeg'),
('One-day tour [Take you to play! ]', '12pm-2pm 2hrs', 'bukit jalil stadium', 'idk how much is the string length but fuck dis shit im not doing this shit for the rest of my life cause life is way more about only making money and this shit aint fun but just good to make money so fuck it. maybe imma do css cause that is abit more about designing the webpage and although this shit is like magic that can allow me to run my page but nah i still aint gonna do it .', '613091af69be3.jpeg'),
('The first online class [Life is also Dharma]', '10pm-12pm 2 hr', 'Public to anyone on or off Facebook', '\"Life is hard, but it has to go on.\" Do you think so sometimes? In fact, life is not difficult, maybe you just used the wrong method. \"Dharma\" beautify your life, purify your heart, and color your day. We are honored to invite lecturer Lin Xiuzhi to explain to us how to effectively apply the Dharma in our lives.', '612e56758b4ce.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `MessageID` int(3) NOT NULL,
  `ParticipantName` varchar(100) NOT NULL,
  `ParticipantEmail` varchar(100) NOT NULL,
  `MessageSubject` varchar(100) NOT NULL,
  `MessageDescription` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`MessageID`, `ParticipantName`, `ParticipantEmail`, `MessageSubject`, `MessageDescription`) VALUES
(24, 'Tomy Yim', 'tomy22@gmail.com', 'Request', 'How to join member of TARUC Buddhist Society ?');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `user_type`, `email`, `password`) VALUES
('jxinnn', 'admin', 'ljiaxin56@gmail.com', '2fbddfdf6b12a41a915ba1747decb3e8'),
('Ong Zheng Xiang', 'admin', 'zx3@gmail.com', '2fbddfdf6b12a41a915ba1747decb3e8'),
('Shian Wei', 'admin', 'sw@gmail.com', '2fbddfdf6b12a41a915ba1747decb3e8'),
('Tomy22', 'user', 'tomy22@gmail.com', 'df2b76419c61902ebd819e0bee08ddac');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `ParticipantName` (`ParticipantName`),
  ADD KEY `EventName` (`EventName`) USING BTREE,
  ADD KEY `EventDuration` (`EventDuration`),
  ADD KEY `EventLocation` (`EventLocation`),
  ADD KEY `Status` (`Status`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`MessageID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `MessageID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
