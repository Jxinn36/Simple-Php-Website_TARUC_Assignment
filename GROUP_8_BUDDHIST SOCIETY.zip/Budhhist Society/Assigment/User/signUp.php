<!--LEE JIA XIN-->
<?php include('includes/functions.php') ?>

<html>
  <head>
	<title>TARC Buddhist Society</title>
        <style> <?php include 'LoginRegis.css'; ?></style>
  </head>
  
<body>
   <div class="header">
      <div class="logo">
          <img  width=130px class="logo" src = "images/logo.jpg" > 
      </div>
    <p>TARUC BUDDHIST SOCIETY</p><br>
    <h2>Sign Up</h2>

    </div>
      <form method="post" action="signUp.php">
        <?php echo display_error(); ?>
            <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="username" value="<?php echo $username; ?>">
            </div>
            <div class="input-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo $email; ?>">
            </div>
            <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password">
            </div>
            <div class="input-group">
                    <label>Confirm password</label>
                    <input type="password" name="comfirmPassword">
            </div>
            <div class="input-group">
                    <button type="submit" class="btn" name="signUp_btn">SIGN UP</button>
            </div>
            <p>
                    Already a member? <a href="userLogin.php">Login</a>
            </p>
    </form>
    </body>
    </html>