<!--EER SHIAN WEI-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>View Bookings</title>
        <?php include 'includes/header.php'; ?>      
    </head>

    <style>    
        .container{
            border: 1px solid black;
            margin-bottom: 95px;
            margin-top: 95px;
        }  
        
        .msg{
            font-size:20px;
            font-weight: bold;
             background-color: #EBEE45;
        }
        #bookings td {
            font-size: 24px;
            font-weight: bold;
        }

        #bookings {
            margin: auto;
            margin-bottom: 50px;
            width: 50%;
            background-color: #EBEED2;
            border-style: outset;
            border-width: 3px;
            border-color: black;
            padding: 10px;
            position: relative;
        }
    </style>

   <body>
    <div class="container" align="center">
        <h1>View Bookings</h1>        
            <?php
            require_once('includes/helper.php');
            if (isset($_SESSION['user'])) {
                $name = $_SESSION['user']['username'];
                $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                $sql = "SELECT * FROM Bookings WHERE ParticipantName = '$name'";
                if ($result = $con->query($sql)) {
                    while ($row = $result->fetch_object()) {
                        printf(
                            '            
                            <table id="bookings">                    
                            <tr>                          
                                <th>
                                    <h1>%s</h1>
                                </th>
                            </tr>
                            <tr>
                                <td>Duration: %s</td>
                            </tr>                        
                            <tr>
                                <td>Location: %s</td>
                            </tr>
                            <tr class="last">
                                <td>Status: %s</td>                              
                            </tr>                          
                            
                            </table>
                            ',
                            $row->EventName,
                            $row->EventDuration,
                            $row->EventLocation,
                            $row->Status
                        );
                        }                     
                    }
                }
                echo '
                <div class="msg">
                Click the following for more information about our upcoming events.
                [ <a href="event.php">Events</a> ]
                </div> 
                ';             
                $result->free();
                $con->close();             
            ?>    
    </div>
</body>
        <footer>
        <?php  include 'includes/footer.php';?>
    </footer>
</html>
