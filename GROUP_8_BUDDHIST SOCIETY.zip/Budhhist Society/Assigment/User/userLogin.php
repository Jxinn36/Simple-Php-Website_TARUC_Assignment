<!--LEE JIA XIN-->
<?php include('includes/functions.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>TARC Buddhist Society</title>
        <style> <?php include 'LoginRegis.css'; ?></style>
</head>
<body>
       <div class="header">
       <div class="logo">
           <img  width=130px class="logo" src = "images/logo.jpg" > 
       </div>
           
        <p>TARUC BUDDHIST SOCIETY</p><br>
	<h2>Login</h2>

	</div>
	   <form method="post" action="userLogin.php">
		<?php echo display_error(); ?>
                <!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
	            <div class="error success" >
			<h3>
		            <?php 
				echo $_SESSION['success']; 
			        unset($_SESSION['success']);
		            ?>
			</h3>
		    </div>
		<?php endif ?>
                
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username"  placeholder="Enter Username" >
		</div>
                
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password" placeholder="Enter your password">
		</div>
                
		<div class="input-group">
			<button type="submit" class="btn" name="login_btn">Login</button>
		</div>
                
		<p> Not yet a member? <a href="signUp.php">Sign up</a> </p>
	</form>
</body>
</html>