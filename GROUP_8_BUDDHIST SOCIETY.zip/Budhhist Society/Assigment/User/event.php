<!--ONG ZHENG XIANG， EER SHIAN WEI-->

<!DOCTYPE html>

<?php
    include('includes/database.php');
?>

<html>
    <head>

        <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TARC Buddhist Society</title>
        <?php  include 'includes/header.php'; ?>
        
          <style>
              <?php include 'event.css'; ?>
              .eventImg{
                 width: 105%;
               }
          </style>
          
    </head>
    
 <body>
        
         <div class="container">
                <img src="images/events.jpeg" alt="aboutUs" style=" width:100%;">
             <div class="content">
                 <h1>Events</h1>
                 <p>Check out TARC Buddhist Society events here!</p>
             </div>
         </div>
     
         <div class="row">
                <br><h1><u>Current Event</u></h1>
                <?php           
            if(isset($_POST['addBooking'])){
                if(isset($_SESSION['user'])){
                    $name = $_POST['addBooking'];
                    $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                    $sql1 = "SELECT * FROM event WHERE Name = '$name'";

                    if($result = $con->query($sql1)){     
                        if($row = $result->fetch_object()){ 
                            $eventName = $row->Name;             
                            $eventDuration = $row->duration;
                            $eventLocation = $row->location;
                            $participantName = $_SESSION['user']['username'];
                            $status = "Going";
                        }                                         
                    }

                $con = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);
                    $sql = '
                        INSERT INTO Bookings (EventName, EventDuration, EventLocation, ParticipantName, Status) 
                        VALUES (?, ?, ?, ?, ?)
                    ';
                    
                    $stm = $con->prepare($sql);
                    $stm->bind_param('sssss', $eventName, $eventDuration, $eventLocation, $participantName, $status);
                    $stm->execute();

                    if($stm->affected_rows > 0){
                        echo '<script>alert("Booking has been added.")</script>';                                
                    }
                    else{
                        echo '<script>alert("Booking has not been added.")</script>';
                    }
                    $stm->close();
                    $con->close();
                }
                else{
                    echo '<script>alert("Please <strong>login</strong> first.</script>';
                }               
            }
            ?>
                <form action="" method="post" id="addBooking">
                    <?php
                        $x = 1;
                        $sql = "SELECT * FROM event";
                        if ($result = $con->query($sql))
                        {
                            while ($row = $result->fetch_object())
                            {
                            printf(' <div class="column">
                                        <div class="event%d"> 
                                            <div class="details">
                                                <div><img class="eventImg" src = "../uploads/%s" ></div>
                                                <h2>%s</h2>
                                                <p><b>duration: %s</b></p>
                                                <p><b>%s</b></p>
                                                <p>%s</p>
                                            
                                                
                                                <button name="addBooking" class="buttonJoin" style="background-color:#7E8632;" value="%s" type="submit">Join Now</button>
                                            </div>
                                        </div>
                                    </div>'
                                    , $x, 
                                    $row->ImageId,
                                    $row->Name,
                                    $row->duration,
                                    $row->location,
                                    $row->description,
                                    $row->Name
                                    );
                                        
                            }
                            $x++;
                        }
                    ?>
                </form>
          </div>
        
    <hr style="height:2px;border:none;color:#333;background-color:#333;" ><br>
  
        <div class="row">
                 <h1><u>Upcoming Event</u></h1>
         

     <div class="column1">
        <div class="upcoming"> 
        <div class="upcomingcol">
            <img src="images/event/event5.jpeg" style="width:100%">
            <img src="images/event/event6.jpeg" style="width:100%">  
        </div>
            
        <div class="upcomingcol">
             <img src="images/event/event7.jpeg" style="width:100%">
            <img src="images/event/event8.jpeg" style="width:100">
        </div>       
        </div>
    </div>
           <div class="column2">
             <div class="upcoming"> 
        <div class="upcomingcol">
            <img src="images/event/event9.jpeg" style="width:100%">
        </div>
        <div class="upcomingcol">
            <img src="images/event/event10.jpeg" style="width:100%">
        </div>

        <div class="upcomingcol">
            <img src="images/event/event11.jpeg" style="width:100%">
        </div>
        <div class="upcomingcol">
            <img src="images/event/event12.jpeg" style="width:100%">
        </div>
        </div>
        </div>      
                 
  </div>

</body>
    <footer>
        <?php include 'includes/footer.php'; ?>
    </footer>
</html>     

