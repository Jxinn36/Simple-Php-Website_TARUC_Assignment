<!--LEE JIA XIN-->
<html>
    <style>
        .main{
            margin: 10px 0px 10px 0px;
        }
        .column{
            border: 1px solid black;
            padding: 10px;
            height:500px;
        }
        form >  input{
            background-color:#E2E8C0;
            border: none;
            color: black;
            padding: 10px 10px;
            text-decoration: none;
            display: inline-block;
            font-size: 10px;
            margin: 4px 2px;
        }
        
         .submit{
              padding: 13px;
            color: none;
            float: left;
            font-size: 18px;
            cursor: pointer;
            border:none;
        }
        
   </style>
    <head>
        <meta charset="UTF-8">
        <title>TARC Buddhist Society profile page</title>
        <?php  include 'includes/header.php'; ?>
        
            <?php
              include 'includes/database.php';
              include 'includes/profileHelper.php';
          
              $hideForm = false;
              $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
              
              if ($_SERVER['REQUEST_METHOD'] == 'GET'){
                   $username = ($_GET['name']);
                   
                   $username  = $con->real_escape_string($username);
                   $sql = "SELECT * FROM users WHERE username = '$username'";
           
             $result = $con->query($sql);
             if ($row = $result->fetch_object()){
               
                 $username = $row->username;
                 $email  = $row->email;
                 $password = $row->password;   
            }
            else{
                echo '
                    <div class="error">
                    Opps. Record not found.
                    [ <a href="adminProfile.php">Back to list</a> ]
                    </div>
                ';
                $hideForm = true; // Flag, "true" to hide the form.
            }

            $result->free();
            $con->close();
        }
        
        if(isset($_POST['submit'])){
            
            $username = $_POST['name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirmPassword'];
      
            $error['email']  = validateEmail($email);
            $error['password'] = validatePass($password);
            $error['confrimPassword'] = validatePass($password , $confirmPassword);
            $error = array_filter($error);
            
            $password = md5($password);
            if (empty($error)){
                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $sql = "
                    UPDATE users SET
                    email = '$email', password = '$password'
                    WHERE username = '$username'
                ";

                if(mysqli_query($con , $sql))                {
                    printf('
                            <div class="info">
                            Event <strong>%s</strong> has been updated.
                            [ <a href="profilepage.php">Back to list</a> ]
                            </div>',
                            $username);
                }
                else{
                    echo '
                       <div class="error">
                       Opps. Database issue. Record not updated.
                       </div>
                    ';
                }

              $con->close();
            }
            
            else{
                // Validation failed. Display error message.
                echo '<ul class="error">';
                foreach ($error as $value){
                    echo "<li>$value</li>";
                }
                echo '</ul>';
            }
        }
        // --> Retrieve Student record based on the passed StudentID.

    ?>
            
 </head>

 <body>
      <div class='main'>
          <div class="column" style="background-color:#CFD897;">
              <div class="editProfile">
                  <h2>Edit Profile:</h2>
                    
                   <form action="" method="post" id="editProfile">
                        
                      <table cellpadding="5" cellspacing="0">
                          <tr>
                              <td><label for="id">Username :</label></td>
                              <td>
                                  <?php echo $username ?>
                                  <input type="hidden" name="name" value="<?php echo $username; ?>">
                              </td>
                          </tr>
                          
                          <tr>
                              <td><label for="email">Email :</label></td>
                              <td>
                                  <input type="email" name="email" id="" value="<?php echo $email;?>">
                              </td>
                          </tr>
                            
                          <tr>
                              <td><label for="password">Password :</label></td>
                              <td>
                                  <input type="password" name="password" id="" value="<?php echo $password;?>">
                              </td>
                          </tr>
             
                          <tr>
                              <td><label for="confirmPassword">Confirm Password :</label></td>
                              <td>
                                  <input type="password" name="confirmPassword" id="">
                              </td>
                          </tr>
                    </table>

                    <button type="submit" name="submit" class="submit">Submit</button>      
               </div>        
           </div>
        </div>
    </body>
    
    <footer>
        <?php  include 'includes/footer.php'; ?>
    </footer>
</html>

