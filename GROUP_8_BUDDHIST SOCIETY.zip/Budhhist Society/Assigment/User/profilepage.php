<?php 
    include('includes/functions.php');
        if (!isLoggedIn()) {
	   $_SESSION['msg'] = "You must log in first";
      	   header('location: userlogin.php');
        }
?>

<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
         <?php include 'includes/header.php'; ?>  
        <style>
            <?php include 'profilepage.css'; ?>
        </style>    
    </head>
 
    <body>
        <?php include 'includes/database.php'; ?>
        
            <?php  if (isset($_SESSION['user'])) {
                $username = $_SESSION['user']['username'];
                $sql = "SELECT * FROM users WHERE username = '$username'";
                $result = mysqli_query($con,$sql);
                $row = mysqli_fetch_assoc($result);
            } ?>
			 
        <div class="up">
           <div class="container">
             <div class="row">
                 <div class="col-4 offset-md-4 form-div">
                     <form action="profilefilepage.php" method="post" enctype="multipart/form-data"> </form>      
                 </div>
             </div>
           </div>
    
           <div class="logo">
<!--              <img  width=130px class="logo" src = "images/user profile.jpeg" > -->
           </div>
             <h2>About</h2>
        </div>

        <div class="disply">
            <div class="group">
               <table>
                  <th colspan="2" align="center"></th>
                     <tr>
                        <td class="rightbar-row"><h2>Name</h2></td>
                        <td class="rb-column2">
                           <h2><?php echo $row['username'] ?></h2>
                        </td>
                     </tr>

                     <tr class="rightbar-row">
                        <td ><h2>Email</h2></td>  
                        <td class="rb-column2">
                            <h2><?php echo $row['email'] ?></h2>
                        </td>
                     </tr>  
               </table>
                
             <p class="hidden"></p>
             
                <tr class="leftbar-row">
                   <td><a href="editUserProfile.php?name=<?php echo $_SESSION['user']['username'];?>" name= "settingButton" class="button">Setting</a></td>
                </tr>

                 <tr class="leftbar-row">
                    <td><a href="viewBooking.php" class="button">View Booking</a></td>           
                 </tr>

                 <tr class="leftbar-row">
                    <?php  if (isset($_SESSION['user'])) : ?>
                       <td> <a href="profilepage.php?logout='1'"  class="button" >Log Out</a> <p class="hidden"></p></td> 
                    <?php endif ?>	          	
                 </tr>
            </div>
	</div>
        
        <p class="hidden"></p>
        
</body>
    
    <footer>
        <?php  include 'includes/footer.php';?>
    </footer>
</html>
