<!--EER SHIAN WEI-->
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
         <?php include 'includes/header.php'; ?>  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    
<style>
     <?php include 'contactUs.css'; ?>
</style>        
  
    <body>
         <div class="container">
            <img src="images/contactUs.jpeg" alt="aboutUs" style=" width:100%;">
               <div class="content">
                   <h1>Contact Us</h1>
                   <p>TARC Buddhist Society welcome you!</p>
               </div>
         </div>
        
       <p class="hidden"></p>
        
        <div class="row">
            <div class="column" style="background-color:#C1CE78;">
                <p><h2>Get in touch</h2></p>
            
               <table class="contactTable">
                <th colspan="2" align="center"></th>
          
                <tr>
                    <td><a href="https://goo.gl/maps/EP5VQ2G9aAJR2JRo6"><i class="fa fa-map-marker"></i></a></td>
                    <td><a href="https://goo.gl/maps/EP5VQ2G9aAJR2JRo6">Kampus Utama, Jalan Genting Kelang, <br>53300 Kuala Lumpur, Wilayah Persekutuan, <br>Kuala Lumpur</a></td>           
                </tr>
                <tr>
                    <td><a href="https://wa.link/2m7ulc"><i class="fa fa-whatsapp"></i></a></td>
                    <td><a href="https://wa.link/2m7ulc">+60 11-5544 0773</a></td>
                </tr>
                <tr>
                    <td><a href="https://www.facebook.com/tarucbs/"><i class="fa fa-facebook-square"></i></a></td>
                    <td><a href="https://www.facebook.com/tarucbs/">Facebook</a></td>
                </tr>
                <tr>
                    <td><a href="https://instagram.com/tbs_buddhist?utm_medium=copy_link"><i class="fa fa-instagram"></i></a></td>
                    <td><a href="https://instagram.com/tbs_buddhist?utm_medium=copy_link">Instagram</a></td>
                </tr>
                <tr>
                    <td><a href="mailto: tbssetapak@gmail.com"><i class="fa fa-envelope"></i></a></td>               
                    <td><a href="mailto: tbssetapak@gmail.com">Email</a></td>
                
            </table>
            
          </div>
            
          </div>
            <div class="column" style="background-color:#B4C45A;">
                <div class="sendMessage">
                    <h2>Write us a message:</h2>
                    <?php
                        $participantName = '';
                        $participantEmail = '';
                        $messageSubject = '';
                        $messageDescription = '';
                        require_once('includes/helper.php');

                        if(!empty($_POST)){
                            $participantName = trim($_POST['ParticipantName']);
                            $participantEmail = trim($_POST['ParticipantEmail']);
                            $messageSubject = trim($_POST['MessageSubject']);
                            $messageDescription = trim($_POST['MessageDescription']);

                            $error['ParticipantName'] = validateParticipantName2($participantName);
                            $error['ParticipantEmail'] = validateParticipantEmail($participantEmail);
                            $error['messageSubject'] = validateMessageSubject($messageSubject);
                            $error['messageDescription'] = validateMessageDescription($messageDescription);
                            $error = array_filter($error);

                            if (empty($error)){
                                $con = new mysqli (DB_HOST, DB_USER, DB_PASS, DB_NAME);
                                $sql = '
                                    INSERT INTO Messages (ParticipantName, ParticipantEmail, MessageSubject, MessageDescription)
                                    VALUES (?, ?, ?, ?)
                                ';

                                $stm = $con->prepare($sql);
                                $stm->bind_param('ssss', $participantName, $participantEmail, $messageSubject, $messageDescription);
                                $stm->execute();

                                if ($stm->affected_rows > 0) {
                                    echo '<script>alert("Message has been sent")</script>';
                                    
                                    $participantName = $participantEmail = $messageSubject = $messageDescription = null;
                                }
                                else{
                                    echo '
                                        <div class="error">
                                        Opps. Message not sent.
                                        </div>
                                    ';
                                }
                                $stm->close();
                                $con->close();
                            }
                            else{
                                echo '<ul class="error">';
                                foreach($error as $value){
                                    echo "<li>$value</li>";
                                }
                                echo '</ul>';
                            }
                        }       
                    ?>                        
                    <form action="" method="post" id="sendMessage">
                        <table>
                            <tr>
                                <td><label for="ParticipantName">Name: </label></td>
                                <td>
                                    <?php    
                                    htmlInputText('ParticipantName', $participantName, 30);
                                    ?>
                                </td>                               
                            </tr>
                            <tr>
                                <td><label for="ParticipantEmail">Email: </label></td>
                                <td>
                                    <?php    
                                    htmlInputText('ParticipantEmail', $participantEmail, 30);
                                    ?>
                                </td>  
                            </tr>
                            <tr>
                                <td><label for="MessageSubject">Subject: </label></td>
                                <td>
                                    <?php    
                                    htmlInputText('MessageSubject', $messageSubject, 30);
                                    ?>
                                </td>  
                            </tr>
                            <tr>
                                <td style="vertical-align:top" ><label for="MessageDescription">Description: </label></td>
                                <td>
                                    <?php    
                                    htmlTextArea('MessageDescription', $messageDescription, 10, 50);
                                    ?>
                                </td>  
                            </tr>
                        </table>
                           <input type="submit" name="submit" value="Send Message" />
                           <input type="reset" name="reset" value="Cancel" />
                    </form>      
                </div>        
            </div>
        </div>  
        
    </body>
   
    <footer>
        <?php  include 'includes/footer.php';?>
    </footer>
</html>

