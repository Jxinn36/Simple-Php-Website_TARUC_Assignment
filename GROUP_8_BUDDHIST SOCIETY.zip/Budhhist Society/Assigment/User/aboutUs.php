<!--LEE JIA XIN-->
<html>
    <head>
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <?php  include 'includes/header.php'; ?>
        <style> <?php include 'aboutUs.css'; ?></style>
    </head>
     
<body>
     <div class="container">
         <img src="images/aboutUs.jpeg" alt="aboutUs" style=" width:100%;">
         <div class="content">
             <h1>About Us</h1>
             <p>Welcome to get to know more about TARC Buddhist Society!</p>
         </div>
     </div>

     <table id="t01">
         <tr>
             <th><h1>&#128270; Our Vision</h1></th>
             <th><h1>&#128216; Our Mission</h1></th> 
          </tr>
        
            <tr>
                <td>
                    <ul>
                        <li>A society supported and continually improved by application of naturalistic knowledge,
                            good social involvement, and continuous mental development.<br><br><br><br></li>
                    </ul>
                </td>

                <td>
                   <ul>
                        <li>Create and foster an active and flourishing Secular Buddhism community's growth and continuity.</li>
                        <li>Create and foster a consistent and accurate understanding of Secular Buddhist teachings and practices.</li>
                        <li>Create and foster a group of Secular Buddhism teachers and leaders. </li>
                    </ul>
                </td> 
             </tr>
      
  
         <tr>
             <th><h1> &#128142; Our Values</h1></th>
             <th><h1> &#127888; Our Team</h1></th>  
          </tr> 
  
         <tr>
             <td>
                 <ul>
                     <li>
                         The teaching - Our club bring the Buddha's teachings on the Four Noble Truths and freedom from suffering.
                     </li>
                     <li>
                         Compassion &nbsp;- We try to ensure loving kindness to ourselves and others  and beyond because we understand the essence of suffering.
                     </li>
                 </ul>
             </td>
             <td>
                 <ul>
                     <li>
                        Our team committee take responsibility in held meaningful events which may include camp, fun time and lecture.
                     </li>
                     <li>
                         Always delighted to have your support. On behalf of all the members ,we would like to extend our warmest and good wishes for all.
                     </li>
                 </ul>
             </td>
         </tr>
          
         </table>
    
      <hr style="height:2px;border:none;color:#333;background-color:#333;" >
      
     <div class="row">
         <h1><u>Committee</u></h1>
        <div class="column">
            <div class="card">
              <img src="images/committee/youyang.jpeg" alt="Avatar" style="width:100%">
            <div class="committeName">
                <h4><b>Pua You Yang</b></h4> 
               <p>Chairman</p> 
            </div>
            </div>
     </div>

     <div class="column">
         <div class="card">
           <img src="images/committee/alan.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
           <h4><b>Alan Low</b></h4> 
           <p>Vice Chairman</p> 
         </div>
         </div>
     </div>
  
     <div class="column">
         <div class="card">
            <img src="images/committee/min er.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
            <h4><b>Chin Min Er</b></h4> 
            <p>Vice Chairman</p> 
         </div>
         </div>  
     </div>   
         
     <div class="column">
         <div class="card">
            <img src="images/committee/hongsheng.jpeg" alt="Avatar" style="width:100%">
          <div class="committeName">
             <h4><b>Chan Ho Seng</b></h4> 
             <p>Secretary</p> 
         </div>
         </div>
     </div>
  
     <div class="column">
         <div class="card">
            <img src="images/committee/keekent.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
             <h4><b>Lor Kin Kent</b></h4> 
             <p>Deputy Secretary</p> 
         </div>
         </div>
     </div>
         
     <div class="column">
         <div class="card">
            <img src="images/committee/kanghong.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
            <h4><b>Yip Kang Ho</b></h4> 
            <p>Financial</p> 
    </tr>
         </div>
         </div>
     </div>    
</div>
      
     <div class="row">
         <div class="column">
         <div class="card">
            <img src="images/committee/alvin.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
            <h4><b>Alvin Teng</b></h4> 
            <p>Deputy Finance</p> 
         </div>
         </div>  
     </div>   
         
        <div class="column">
            <div class="card">
              <img src="images/committee/cheeyian.jpeg" alt="Avatar" style="width:100%">
            <div class="committeName">
                <h4><b>Tan Chee Yian</b></h4> 
               <p>Multimedia</p> 
            </div>
            </div>
        </div>
 
     <div class="column">
         <div class="card">
           <img src="images/committee/weidong.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
           <h4><b>Lee Wei Dong</b></h4> 
           <p>Multimedia</p> 
         </div>
         </div>
     </div>
  
     <div class="column">
         <div class="card">
            <img src="images/committee/kaifeng.jpeg" alt="Avatar" style="width:100%">
          <div class="committeName">
             <h4><b>Hew Kai Feng</b></h4> 
             <p>Event Coordinator</p> 
         </div>
         </div>
     </div>
  
     <div class="column">
         <div class="card">
            <img src="images/committee/issac.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
             <h4><b>Issac Yeow</b></h4> 
             <p>Event Coordinator</p> 
         </div>
         </div>
     </div>
         
     <div class="column">
         <div class="card">
            <img src="images/committee/peggy.jpeg" alt="Avatar" style="width:100%">
         <div class="committeName">
            <h4><b>Peggy Low</b></h4> 
            <p>Event Coordinator</p> 
         </div>
         </div>
          <br> <br> <br> <br> 
     </div>
    </div>
     
   </table>
</body>
    
    <footer>
         <?php include 'includes/footer.php'; ?>
    </footer>  
</html>
