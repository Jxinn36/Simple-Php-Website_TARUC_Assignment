<!--LEE JIA XIN-->

<?php
   include "includes/database.php";

   //connect databse  
   $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if(isset($_POST['settingButton'])){

        $username = $_POST['name'];
        $email = $_POST['email'];
        $password= $_POST['password'];

        $query = "UPDATE users SET email ='$email',password ='$password' WHERE username ='$username' ";
        $query_run = mysqli_query($con,$query);

        if($query_run){
           $_SESSION['status']="Updated succeesfully";
           header ("Location : ../editUserProfile.php");
        }else{

            $_SESSION['status']="Not updated";
            header ("Location : ../editUserProfile.php");
        }
    }

    function validateEmail($email){
       if ($email == null){
           return 'Please enter <strong>email</strong>.';
       }
    }
    
    function validatePass($password){
        if ($password == null){
            return 'Please enter <strong>password</strong>.';
        }
        // Prevent hacks.
        else if (strlen($password) > 30) { 
            return '<strong>password</strong> must not more than 30 letters.';
        }
    }
    
    function validateConfirmPassword($password , $confirmPassword){
        if ($password != $confirmPassword){
            return '<strong>password</strong> not match.';
       }
    }
