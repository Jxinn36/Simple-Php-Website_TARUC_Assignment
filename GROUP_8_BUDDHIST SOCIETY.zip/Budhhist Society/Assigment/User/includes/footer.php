<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>TARC Buddhist Society</title>
   
  <style> 
      
       /* ===============================
                      footer
          ===============================
       */

       footer {                        /*background*/
          text-align: center;
          padding: 3px;
          background-color: #CFD897;
          color: white;
          width: 100%;
  
       }   

       .footer {                       /*background*/
          background-color: #CFD897;
          border-style: solid;
          border-top-color: black;
          width:100%;
          text-align: left;
          padding: 3px;
          background-color: #CFD897;
          color: white;
          overflow:hidden;
          padding: 20px 10px;
       }    

       .footer img{ 
          border-radius: 50%;         /*round footer image*/
          display: block;
          margin-left: 50px;          /*place image*/
       }

      .footer p, .footer h1, .footer h2{
            color: black;
       }
       
       /* ===============================
                    Navigation
          ===============================
       */
       nav.horizontal ul {
          display: -webkit-flex;
          display: flex;
          -webkit-flex-flow: column wrap;
          flex-flow: column wrap;
       }

       nav.horizontal a{
           color: black;
           background-color: transparent;
           text-decoration: none;
       }

       nav.horizontal a:hover {           /*when point on it*/
           color: #274d23;
           background-color: transparent;
           text-decoration: underline;
       }
       nav.horizontal a:active {
          color: Black;
          background-color: transparent;
          text-decoration: underline;
       }
       
       /* ===============================
                 Mobile Devices
          ===============================
       */
          * {
               box-sizing: border-box;
            }

         @media screen and (max-width: 800px) {
             .footer img{ 
                 margin-left: 10px;          /*place image*/
             }
        }
   </style>
 </head>
    
 <footer>
    <div class="footer">    
         <table style="width:100%">
          <thead>
            <th>
              <td> 
                 <img  width=140px src = "images/logo.jpg" class="center">
                 <h2>TARC Buddhist Society<h2>
              </td>
            </th>
                             
            <th>
              <td><nav class="horizontal">  
                 <h1>Stay Tuned !</h1>
                 <p>Connect with us and stay in the loop.</p><br>
                 <a href="https://www.facebook.com/tarucbs/" target="_blank" class="fa fa-facebook-square" style="font-size:24px" ></a>
                 <a href="https://instagram.com/tbs_buddhist?utm_medium=copy_link" target="_blank" class="fa fa-instagram" style="font-size:24px" ></a>
                 <a href="mailto: tbssetapak@gmail.com"  target="_blank" class="fa fa-envelope" style="font-size:24px" ></a>
                 <a href="https://wa.link/2m7ulc" target="_blank" class="fa fa-whatsapp" style="font-size:24px"></a>
              </nav>
              </td>
            </th>

            <th>
               <td><nav class="horizontal">  
                   <ul>
                     <h1>Pages</h1>
                     <a href="home.php">Home</a>
                     <a href="aboutUs.php">About</a>
                     <a href="event.php">Events</a>
                     <a href="contactUs.php">Contact</a>
                     <a href="profilepage.php">Profile</a>
                   </ul>
                 </nav>
               </td>
            </th>
          </thead>
         </table>
     </div>
 </footer>
 </html>
