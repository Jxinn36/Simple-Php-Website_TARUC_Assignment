<!--LEE JIA XIN-->

<?php 
session_start();

// connect to database
$db = mysqli_connect('localhost', 'root', '', 'assignment');

$username = "";
$email    = "";
$errors   = array(); 

// call the signUp() function if signUp_btn is clicked
if (isset($_POST['signUp_btn'])) {
    signUp();
}

// REGISTER USER
function signUp(){
    global $db, $errors, $username, $email;

        $username    =  receive($_POST['username']);
	$email       =  receive($_POST['email']);
	$password  =  receive($_POST['password']);
	$comfirmPassword  =  receive($_POST['comfirmPassword']);

        
         if(empty($username) || empty($email)|| empty($password)|| empty($confirmPassword)){
	//validation
	 if (empty($username)) { 
	    array_push($errors, "Username is required"); 
	}
	 if (empty($email)) { 
            array_push($errors, "Email is required"); 
	}
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
            array_push($errors, "Wrong email format"); 
        }
        if (strlen($password) < 7 || strlen($password) > 16){
            array_push($errors, "Password length should be in 7-16 values "); 
        }        
	if (empty($password)) { 
	    array_push($errors, "Password is required"); 
	}
	if ($password != $comfirmPassword) {
            array_push($errors, "Passwords not match");
	}     
        
        $sql_u = "SELECT * FROM users WHERE username='$username'";
  	$chck_u = mysqli_query($db, $sql_u);

  	if (mysqli_num_rows($chck_u) > 0) {
            array_push($errors, "Username already taken");	
  	}
        
	// if no errors thn register proccess
	if (count($errors) == 0) {
		$password = md5($password);//encrypt password 

                //store the type of user to verify isAdmin or isUser
		if (isset($_POST['user_type'])) {
			$user_type = receive($_POST['user_type']);
			$query = "INSERT INTO users (username, email, user_type, password) 
					  VALUES('$username', '$email', '$user_type', '$password')";
                       
			mysqli_query($db, $query);
                   
			$_SESSION['success']  = "You have successfully created an acoount!!";
			header('location: userLogin.php');
                }else{
                            $query = "INSERT INTO users (username, email, user_type, password) 
                            VALUES('$username', '$email', 'user', '$password')";

                            mysqli_query($db, $query);

                            $logged_in_user_name = mysqli_insert_id($db);

                            $_SESSION['user'] = getUserByname($logged_in_user_name); 
                            $_SESSION['success']  = "Sucessfully created account <br>login now!";
                            header('location: userLogin.php');				

                     }
                
                }
        
       }
}

// return user array from their name
function getUserByname($username){
    global $db;	
    $query = "SELECT * FROM users WHERE username=" . $username;
    $result = mysqli_query($db, $query);
    $user = mysqli_fetch_assoc($result);
    return $user;
}

function receive($val){
    global $db;
    return mysqli_real_escape_string($db, trim($val));
}

function display_error() {
    global $errors;

    if (count($errors) > 0){
	echo '<div class="error">';
            foreach ($errors as $error){
		echo $error .'<br>';
            }
	echo '</div>';
    }
}	

function isLoggedIn()
{
    if (isset($_SESSION['user'])) {
            return true;
    }else{
	return false;
    }
}

// logout button function
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['user']);
    header("location: userLogin.php");
}

/* ===============================
             LOGIN
   ===============================
*/

// call the login() function when register_btn is clicked
if (isset($_POST['login_btn'])) {
    login();
}

function login(){
    global $db, $username, $errors;

    // grap form values
    $username = receive($_POST['username']);
    $password = receive($_POST['password']);
    
    // validation
    if (empty($username)) {
	array_push($errors, "Username is required");
    }
    if (empty($password)) {
	array_push($errors, "Password is required");
    }

    // if no errors 
    if (count($errors) == 0) {
	$password = md5($password);
        
        $query = "SELECT * FROM users WHERE username='$username' AND password='$password' LIMIT 1";
	$results = mysqli_query($db, $query);

            if (mysqli_num_rows($results) == 1) { // user found
		// check if user is admin or user
		$logged_in_user = mysqli_fetch_assoc($results);
                    
		if ($logged_in_user['user_type'] == 'admin') {
                    // if admin
                    $_SESSION['admin'] = $logged_in_user;
                    $_SESSION['success']  = "You are now logged in";
       		    header('location: ../admin/adminProfile.php');		  
		}else{
                    //if user
                    $_SESSION['user'] = $logged_in_user;
                    header('location: home.php');        
		}
	    }else {
		array_push($errors, "Wrong username/password ");
            }
    }
}