<!--LEE JIA XIN-->
<?php require_once 'functions.php'; ?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <style><?php include 'includes/header.css'; ?></style>
    </head>
     
    <body>
        <?php
             if(empty($_SESSION['user'])){
        ?>
        <!--if haven login-->
           <header>
              <div class="header">
                 <img  width=120px class="logo" src = "images/logo.jpg" > 
  
                <div class="topnav">
                   <a href="home.php" >Home</a>  
                   <a href="aboutUs.php" >About</a> 
                   <a href="event.php" >Events</a>
                   <a href="contactUs.php" >Contact</a>
                   <a href="userLogin.php" >Login</a>
                </div>
              </div>
       </header>
        
       <?php
        } else {?>
         <!--if logged in-->
           <header>
              <div class="header">
                  <img  width=120px class="logo" src = "images/logo.jpg" > 
  
                <div class="topnav">
                   <a href="home.php" >Home</a>  
                   <a href="aboutUs.php" >About</a> 
                   <a href="event.php" >Events</a>
                   <a href="contactUs.php" >Contact</a>
                   <a href="profilepage.php" ><img  src = "images/user profile.jpeg" height=30px width=30px>Profile</a>
                </div>
              </div>
          </header>
             <?php
        }?>
    </body>
</html>
