<!--EER SHIAN WEI-->
<?php

//connect database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'assignment');

///////////////////////////////////////////////////////////////////////////////
// Lookup tables //////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// Return array of event names
function getEventNames(){
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db = mysqli_select_db($conn, "assignment");

    $sql = "SELECT Name FROM event";
    $result = mysqli_query($conn, $sql);
    
    $final = array();
    $temp = array();

    while($row = mysqli_fetch_array($result)){
        $temp = $row['Name'];
        array_push($final, $temp);
    }
    return $final;
}

//Return array of event durations 
function getEventDurations(){
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db = mysqli_select_db($conn, "assignment");

    $sql = "SELECT duration FROM event";
    $result = mysqli_query($conn, $sql);

    $final = array();
    $temp = array();
    
    while($row = mysqli_fetch_array($result)){
        $temp = $row['duration'];
        array_push($final, $temp);
    }
    return $final;
}

// Return an array of event locations
function getEventLocations(){
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db = mysqli_select_db($conn, "assignment");

    $sql = "SELECT location FROM event";
    $result = mysqli_query($conn, $sql);

    $final = array();
    $temp = array();
    
    while($row = mysqli_fetch_array($result)){
        $temp = $row['location'];
        array_push($final, $temp);
    }
    return $final;
}

// Return array of participant names
function getParticipantNames(){
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db = mysqli_select_db($conn, "assignment");

    $sql = "SELECT username FROM users";
    $result = mysqli_query($conn, $sql);

    $final = array();
    $temp = array();
    
    while($row = mysqli_fetch_array($result)){
        $temp = $row['username'];
        array_push($final, $temp);
    }
    return $final;
}

// Return an array of all statuses
function getStatus() 
{
    return array(
        'Going' => 'Going',
        'Pending' => 'Pending',
        'Cancelled' => 'Cancelled'
    );
}

// Array versions of lookup tables.
$EVENT = getEventNames();
$EVENTDURATION = getEventDurations();
$EVENTLOCATION = getEventLocations();
$PARTICIPANT = getParticipantNames();
$STATUS = getStatus();


///////////////////////////////////////////////////////////////////////////////
// HTML helpers ///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// Print a <select> element.
function htmlSelect($name, $items, $selectedValue = '', $default = '')
{
    printf('<select name="%s" id="%s">' . "\n",
    $name, $name);

    if ($default != null)
    {
        printf('<option value="">%s</option>', $default);
    }

    foreach ($items as $value => $text)
    {
        printf('<option value="%s" %s>%s</option>' . "\n",
               $value,
               $value == $selectedValue ? 'selected="selected"' : '',
               $text);
    }
    
    echo "</select>\n";
}

// Print a hidden <select> element.
function htmlHiddenSelect($name, $items, $selectedValue = '', $default = '')
{
    printf('<select style="display:none" name="%s" id="%s">' . "\n",
    $name, $name);

    if ($default != null)
    {
        printf('<option value="">%s</option>', $default);
    }

    foreach ($items as $value => $text)
    {
        printf('<option value="%s" %s>%s</option>' . "\n",
               $value,
               $value == $selectedValue ? 'selected="selected"' : '',
               $text);
    }
    
    echo "</select>\n";
}

// Print a <input type="text"> element.
function htmlInputText($name, $value = '', $maxlength = '')
{
    printf('<input type="text" name="%s" id="%s" value="%s" maxlength="%s" />' . "\n",
    $name, $name, $value, $maxlength);
}

// Print a <input type="password"> element.
function htmlInputPassword($name, $value = '', $maxlength = '')
{
    printf('<input type="password" name="%s" id="%s" value="%s" maxlength="%s" />' . "\n",
    $name, $name, $value, $maxlength);
}

// Print a <input type="hidden"> element.
function htmlInputHidden($name, $value = '')
{
    printf('<input type="hidden" name="%s" id="%s" value="%s" />' . "\n",
    $name, $name, $value);
}

// Print a group of <input type="radio"> elements.
function htmlRadioList($name, $items, $selectedValue = '', $break = false)
{
    foreach ($items as $value => $text)
    {
        printf('
            <input type="radio" name="%s" id="%s" value="%s" %s />
            <label for="%s">%s</label>' . "\n",
            $name, $value, $value,
            $value == $selectedValue ? 'checked="checked"' : '',
            $value, $text);

        if ($break)
            echo "<br />\n";
    }
}

// Print a <textarea> element.
function htmlTextArea($name, $value = '', $rows, $cols){
    printf('<textarea style="resize:none" name="%s" id="%s" rows="%d" cols="%d" >%s</textarea>' . "\n",
    $name, $name, $rows, $cols, $value);
}

///////////////////////////////////////////////////////////////////////////////
// Validators /////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
function validateStatus($status){
    if($status == null){
        return 'Please enter <strong>Event Name</strong>.';
    }
    else if (!array_key_exists($status, getStatus())){
        return 'Invalid <strong>Event Name</strong> code detected.';
    }
}

function validateEventName($eventName){
    if ($eventName == null){
        return 'Please enter <strong>Event Name</strong>.';
    }
    else if (!array_key_exists($eventName, getEventNames())){
        return 'Invalid <strong>Status</strong> code detected.';
    }
}

function validateParticipantName($participantName, $eventName){
    $exist = false;

    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $id  = $con->real_escape_string($participantName);
    $sql = "SELECT ParticipantName FROM Bookings WHERE EventName = '$eventName' AND ParticipantName = '$participantName'";

    if ($result = $con->query($sql))
    {
        if ($result->num_rows > 0)
        {
            $exist = true;
        }
    }

    $result->free();
    $con->close();

    return $exist;
}

function validateParticipantName2($participantName){
    if($participantName == null){
        return 'Please enter a <strong>Name</strong>.';
    }
}

function validateParticipantEmail($participantEmail){
    if($participantEmail == null){
        return 'Please enter a <strong>Email</strong>.';
    }
}

function validateMessageSubject($messageSubject){
    if($messageSubject == null){
        return 'Please enter a <strong>Subject</strong>.';
    }
}

function validateMessageDescription($messageDescription){
    if($messageDescription == null){
        return 'Please enter a <strong>Description</strong>.';
    }
}
?>
