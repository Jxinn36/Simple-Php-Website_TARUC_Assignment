<?php

    //connect to a database
    $dbHost ="localhost";
    $dbUser ="root";
    $dbPass ="";
    $dbName ="assignment";

    //connection to database
    $con = mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);

    if (!$con){ 
        die("Database connection failed !");
    }

?>
