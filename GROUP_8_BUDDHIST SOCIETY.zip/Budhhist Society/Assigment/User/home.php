<!--LEE JIA XIN-->
<?php
    $con = mysqli_connect("localhost", "root", "", "assignment");

?>

<html>
    <head>
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>TARC Buddhist Society</title>
     
          <?php include 'includes/header.php'; ?>   
         <style> <?php include 'home.css'; ?> </style>
         
         <script
             src="https://code.jquery.com/jquery-1.12.4.min.js">
         </script>
    </head>
       
<body>       
    <div class="container">
       <img src="images/Home.jpeg" alt="aboutUs" style=" width:100%;">
           <div class="content">
             <h1>Home</h1>
             <p>TARC Buddhist Society welcome you!</p>
           </div>
    </div>
  
 
    <div class="row">
       <div class="leftcolumn">
          <div class="card">
                
                 <tr>
                   <td> <img src="images/schedule.png" width="600" height="400" alt=""> </td>
                 </tr>
               
          </div>
       </div>
    
    <div class="rightcolumn">  
       <div class="card1">
           <h3>Features Event</h3>
           <p>Due to this pandemic, 
           <br>our Buddhist Class will be held <br>every Thursday, <br>8pm - 10pm at ZOOM. 
           <br><br>Note down our class schedule, <br>so that you will not miss it out! 
           <br><br>Stay tuned with us ! <br>Wish you stay healthy and safe all the time!
           </p>
               <button onclick="window.location.href='event.php'" class="button button1"> <span>View More</span></button>
       </div>
     </div>
</div>
    
        <hr style="height:2px;border:none;color:#333;background-color:#333;" >
         
  <div class="row">
     <div class="leftcolumn1">
        <div class="card1">
            <h3>Social Media</h3>
                <p>Do follow our Buddhist Society social media page. 
                    <br><br>Let's follow the step of the Lord Buddha. 
                    <br>We learn and practice the profound Dharma in our daily life to create a better self intrinsically.
                </p>
               <button onclick="window.location.href='contactUs.php'" class="button"><span>Contact Us</span></button>
        </div>
     </div>
    
    <div class="leftcolumn1">
        <div class="card">
             <div class="socialMediapage">
                <img src="images/FB Page.jpg" alt="ig page" class="image" style="width:100%">
                    <div class="overlay">
                       <div class="text">Our Facebook Page</div>
                    </div>
             </div> 
        </div>
     </div>
    
    <div class="leftcolumn1">
       <div class="card">
           <div class="socialMediapage">
              <img src="images/ig Page.jpeg" alt="ig page" class="image" style="width:100%">
                 <div class="overlay">
                    <div class="text">Our Instagram Page</div>
                </div>
            </div> 
       </div>
     </div>

</div>
        
        
    <hr style="height:2px;border:none;color:#333;background-color:#333;" >
   
    <div class="row">
          <div class="leftcolumn2">
             <div class="card1">
              
                <h3>Project Completed </h3>
                <h2 class ="counter">20 </h2>
                           </div>
          </div>

      <div class="leftcolumn2">
          <div class="card1">
             <h3>Users Connected </h3>
             <h2 class ="counter">60 </h2>
         </div>
      </div>

      <div class="leftcolumn2">
          <div class="card1">
            <h3> Members </h3>
            <h2 class ="counter">10 </h2>
          </div>
      </div>

      <div class="leftcolumn2">
         <div class="card1">
            <h3>Achievements </h3>
            <h2 class ="counter">25 </h2>
         </div>
      </div>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
        <script src = "jquery.counterup.min.js"></script>
        
         <script>
         jQuery(document).ready(function($){
             $('.counter').counterUp({
               delay: 20,    // speed
               time: 1500   //time to complete
             });
         });
         </script>
   </div>
  
</body>
    
<footer>
    <?php include 'includes/footer.php'; ?>
</footer>  

</html>
      
       