<!--ONG ZHENG XIANG-->
<?php
include('includes/database.php');
include('includes/eventFunction_dbh.php');
?>
<html>
    <head>
        <style>
            <?php
               include('adminEvent.css'); 
            ?>
        </style>

        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <?php  
        session_start();
        include 'adminBackground.php'; 
        if (isset($_POST['delete'])) // If "delete" button is clicked.
        {
            $checked = $_POST['checked'];
            // NOTE:
            // -----
            // All checkboxes are named as "checked[]" value their value set to
            // the respective StudentID. For such, $checked is an array containing
            // all of the selected StudentID.

            if (!empty($checked)) // If at least 1 checkbox is checked.
            {
                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

                // Real escape all StudentID.
                foreach ($checked as $value)
                {
                    $escaped[] = $con->real_escape_string($value);
                }

                // SQL with WHERE field IN (...) clause.
                $sql = "DELETE FROM event WHERE Name IN ('" .
                     implode("','", $escaped) . "')";

                if ($con->query($sql))
                {
                    printf('
                        <div class="info" style="color: white;">
                        <strong>%d</strong> record(s) has been deleted.
                        </div>',
                        $con->affected_rows);
                }

                $con->close();
            }
        }
        
        ?>
        
    </head>
    
    <?php
 $sql = "SELECT  * FROM event ";
 if(isset($_POST['search'])){
     $searchName = $_POST['searchName'];
     $sql = "SELECT *  FROM event WHERE Name LIKE '%$searchName%'";
     
 }
 ?>
    <body>
     <div class="container">
        <div class="search">
            <form class="searchName" action="" method ="POST">
                <input type="text" id="search" placeholder="Search by name" name="searchName">
                
                   <button class="search-btn" type="submit" name="search"><i class="fa fa-search" ></i></button>
           
            </form>
        </div>
        <h1>Current events</h1>
        <div class="table">
            <form action="" method="post">
        <?php
        require_once('includes/database.php');
        require_once ('includes/eventFunction_dbh.php');
        $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
        
        echo '<table border="1" cellpadding="5" cellspacing="0">';
        echo '<tr>';
        echo '<th>&nbsp;</th>';
        echo '<th style="width:3%;">No</th>';
        echo '<th style="width:55%;">Event</th>';
        echo '<th style="width:10%;">Date</th>';
        echo '<th style="width:7%;">Details</th>';
        echo '<th style="width:10%;">&nbsp;</th>';
        echo '<th style="width:7%;">&nbsp;</th>';
        echo '<th style="width:20%;">&nbsp;</th>';// <-- Addtion column header (empty).
        echo '</tr>';
        

        if ($result = $con->query($sql))
        {
            $x = 1;
            while ($row = $result->fetch_object())
            {
                
                printf('
                    <tr>
                    <td>
                        <input type="checkbox" name="checked[]" value="%s" />
                    </td>
                    <td>%d</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td><a href="adminGallery.php?name=%s" class="editButton">...</a></td>
                    <td><a href="adminEditImages.php?name=%s" class="editButton">edit Image</a></td>
                    <td><a href="adminEditEvent.php?name=%s" class="editButton">edit</a></td>
                    <td><a href="adminDeleteEvent.php?name=%s" class="editButton">Delete</a></td>
                    </tr>',
                    $row->Name,
                    $x,
                    $row->Name,
                    $row->duration,
                    $row->Name,   
                    $row->Name,
                    $row->Name,
                    $row->Name
                );
                $x++;
            }
        }
        
        echo '</table>'
        ?>
        <br />
        <input type="submit" class="delete" name="delete" value="Delete Checked"
               onclick="return confirm('This will delete all checked records.\nAre you sure?')" />
        </form>
        </div>
        <div class='button1'>
            <a href="adminAddEvent.php" class="button"><h1>Add New Event</h1></a>
        </div>
        </div>
    </body>
  