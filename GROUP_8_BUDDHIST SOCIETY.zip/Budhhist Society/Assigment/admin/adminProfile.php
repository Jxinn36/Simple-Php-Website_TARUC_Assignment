<!--LEE JIA XIN-->
<?php include '../User/includes/functions.php'; ?>
<?php include 'includes/database.php'; ?>
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
         <meta name="viewport" content="width=device-width, initial-scale=1" />
         <?php include 'adminBackground.php'; 
            if(isset($_POST["logout"])){
                session_start();
                session_unset();
                session_destroy();

                header("Location:../User/userLogin.php?");
            }
         ?> 
         <style>  <?php include 'adminProfile.css'; ?> </style>
       
    </head>
    
    <body>
           <?php  if (isset($_SESSION['admin'])) {
                                    
                   $username = $_SESSION['admin']['username'];
                   $sql = "SELECT * FROM users WHERE username = '$username'";
                   $result = mysqli_query($con,$sql);
                      
                    $row = mysqli_fetch_assoc($result);
            } ?>

       <div class="row">
          <div class="column2" style="background-color:#B4C45A;">
            <div class="rightbar-header">
                <h1>About</h1>
            </div>
                
            <table>
                <th colspan="2" align="center"></th>
                    <tr class="rightbar-row">
                          <td class="rightbar-row"><h2>Name</h2></td>
                          <td class="rb-column2">       
                             <h2><?php echo $row['username'] ?></h2>
                          </td>    
                    </tr>
                    
                    <tr class="rightbar-row">
                         <td><h2>Email</h2></td>  
                         <td class="rb-column2"> 
                            <h2><?php echo $row['email'] ?></h2>
                    </tr>  
         
                   <tr class="rightbar-row">
                       <td></td>
                       <td><a href="adminProfileSetting.php?name=<?php echo $_SESSION['admin']['username'];?>" name= "settingButton" class="button">Setting</a></td>

                   <?php  if (isset($_SESSION['admin'])) : ?>
                        <td> 
                            <form method="POST" action = ""><button class ="button1" type="submit" name="logout"> Log Out</button>   </form>
                        </td>    
                      <?php endif ?>
                   </tr>
            </table>
        </div>        
   </div>       
</body>
        
</html>