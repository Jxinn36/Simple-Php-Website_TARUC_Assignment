<!--EER SHIAN WEI-->
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php session_start(); ?>
        <?php include 'adminBackground.php'; ?> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <style>
        <?php include 'adminDeleteMessage.css'; ?> 
    </style>
    
    <body>
        <div class="container">
            <?php
            require_once('includes/helper.php');
            if($_SERVER['REQUEST_METHOD'] == 'GET'){
                $id = strtoupper(trim($_GET['id']));

                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $id = $con->real_escape_string($id);
                $sql = "SELECT * FROM Messages WHERE MessageID = '$id'";

                $result = $con->query($sql);
                if($row = $result->fetch_object()){
                    $id = $row->MessageID;
                    $name = $row->ParticipantName;
                    $email = $row->ParticipantEmail;
                    $subject = $row->MessageSubject;
                    $description = $row->MessageDescription;

                    printf('
                        <p>Are you sure you want to delete the following message?</p>
                        <table>
                            <tr>
                                <td>Message ID: </td>
                                <td>%s</td>
                            </tr>
                            <tr>
                                <td>Name: </td>
                                <td>%s</td>
                            </tr>
                            <tr>
                                <td>Email: </td>
                                <td>%s</td>
                            </tr>
                            <tr>
                                <td>Subject: </td>
                                <td>%s</td>
                            </tr>
                            <tr>
                                <td>Description: </td>
                                <td>%s</td>
                            </tr>
                        </table>
                        <form action="" method="post">
                            <input type="hidden" name="id" value="%s" />
                            <input type="submit" class="yes" name="yes" value="Yes" />
                            <input type="button" class="cancel " value="Cancel" onclick="location=\'adminMessages.php\'" />
                        </form>', 
                        $id, $name, $email, $subject, $description, $id);
                }
                else{
                    echo '
                        <div class="error">
                        Message not found.
                        [ <a href="adminMessages.php">Back to list.</a> ]
                        </div>
                        ';
                }
                $result->free();
                $con->close();
            }
            else{
                $id = strtoupper(trim($_POST['id']));
                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $sql = '
                    DELETE FROM Messages WHERE MessageID = ?
                ';
                $stm = $con->prepare($sql);
                $stm->bind_param('s', $id);
                $stm->execute();
                if($stm->affected_rows > 0){
                    printf('
                        <div class="info">
                        Message has been deleted.
                        [ <a href="adminMessages.php">Back to list</a> ]
                        </div>'
                    );
                }
                else{
                    echo '
                    <div class="error">
                    Database issue. Message not deleted.
                    </div>
                    ';
                }
                $stm->close();
                $con->close();
            }
            ?>
        </div>
    </body>
</html>