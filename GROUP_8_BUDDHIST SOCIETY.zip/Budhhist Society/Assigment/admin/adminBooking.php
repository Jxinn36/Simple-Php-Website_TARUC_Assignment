<!--EER SHIAN WEI-->
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php session_start(); ?>
        <?php include 'adminBackground.php'; ?> 
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <style><?php include 'adminBooking.css'; ?> </style>
    <body>
        <div class="container">
            <h1>Bookings</h1>
            <form action="" method="post">
            <?php
            require_once('includes/shianWei_helper.php');

            if(isset($_POST['delete'])){
                $checked = $_POST['checked'];
                if(!empty($checked)){
                    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                    foreach ($checked as $value){
                        $escaped[] = $con->real_escape_string($value);
                    }
                    $sql = "DELETE FROM Bookings WHERE BookingID IN ('" .
                            implode("','", $escaped) . "')";
       
                    if($con->query($sql)){
                        printf('
                            <div class="info">
                            <strong>%d</strong> booking(s) has been deleted.
                            </div>', 
                            $con->affected_rows);
                    }
                    $con->close();
                }
            }

            $headers = array(
                'BookingID' => 'Booking ID',
                'EventName' => 'Event Name',
                'EventDuration' => 'Event Duration',
                'EventLocation' => 'Event Location',
                'ParticipantName' => 'Participant Name',
                'Status' => 'Status'               
            );

            $sort = (array_key_exists($_GET['sort'], $headers) ? $_GET['sort'] : 'BookingID');
            $order = ($_GET['order'] == 'DESC' ? 'DESC' : 'ASC');

            echo '<table class="content">';
            echo '<tr>';
            echo '<th>&nbsp;</th>';

            foreach($headers as $key => $value){
                if($key == $sort){
                    printf('
                        <th>
                        <a href="?sort=%s&order=%s">%s</a>

                        </th>',
                        $key,
                        $order == 'ASC' ? 'DESC' : 'ASC',
                        $value
                    );
                }
                else{
                    printf('
                        <th>
                        <a href="?sort=%s&order=ASC">%s</a>
                        </th>',
                        $key,
                        $value);
                }
            }
            echo '<th>&nbsp;</th>';
            echo '</tr>';

            $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $sql = "SELECT * FROM Bookings ORDER BY $sort $order";
              
                if($result = $con->query($sql)){
                    while($row = $result->fetch_object()){
                        printf('
                            <tr>
                            <td>
                                <input type="checkbox" name="checked[]" value="%s"/>
                            </td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>
                                <a href="adminEditBooking.php?id=%s">Edit</a>
                                <a href="adminDeleteBooking.php?id=%s">Delete</a>
                            </td>
                            </tr>',
                            $row->BookingID,
                            $row->BookingID,
                            $row->EventName,                                
                            $row->EventDuration,
                            $row->EventLocation,
                            $row->ParticipantName,
                            $row->Status,
                            $row->BookingID,
                            $row->BookingID
                        );
                    }
                }
                printf('
                    <tr>
                    <td colspan="10">
                        %d booking(s) returned.
                       
                    </td>
                    </tr>',
                    $result->num_rows
                );
                echo '</table>';
                $result->free();
                $con->close();
            ?>
            <br/>
            <input type="submit" name="delete" class="delete" value="Delete Checked"
                onclick="return confirm('This will delete all checked bookings.\nAre you sure?')" />
            </form>  
        </div>
    </body>
</html>