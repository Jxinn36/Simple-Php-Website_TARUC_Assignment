<!--ONG ZHENG XIANG-->
<?php
// Check if delete button was clicked.
if (isset($_POST['delete']))
{
    // Delete the file.
    $image = $_POST['image'];
    $path = "../uploads/$image";
    unlink($path);
}
session_start();
include 'adminBackground.php';
include 'includes/database.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <title>Image Gallery</title>
    </head>
       <style>
           <?php
              include 'adminGallery.css';
           ?>
      </style>

    <body>
        

        <div class="container">
            <h2>Event Detail</h2>
            <div class="table">
            <?php
            // Display all file names from uploads folder as an list.
            
            echo '<table border="1" cellpadding="5" cellspacing="0">';
            echo '<tr>';
            echo '<th>Event</th>';
            echo '<th>Date</th>';
            echo '<th>Location</th>';
            echo '<th>Description</th>';
            echo '<th>&nbsp;</th>';
            echo '<th>&nbsp;</th>';
            echo '<th>&nbsp;</th>';// <-- Addtion column header (empty).
            echo '</tr>';
            
            
            if ($_SERVER['REQUEST_METHOD'] == 'GET')
            {
                $name = ($_GET['name']);

                $db = mysqli_connect("localhost", "root", "", "assignment");
                $name  = $con->real_escape_string($name);
                $sql = "SELECT * FROM event WHERE Name = '$name'";

                $result = mysqli_query($db, $sql);
                if ($row = $result->fetch_object())
                {
                    
                    $name = $row->Name;
                    $duration  = $row->duration;
                    $location = $row->location;
                    $description = $row->description;
                    
                    printf('
                    <tr>
                    <td>%s</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td><img class="eventImg" src = "../uploads/%s" ></td>
                    <td><a href="adminEditEvent.php?name=%s" class="editButton">edit</a></td>
                    <td><a href="adminDeleteEvent.php?name=%s" class="editButton">Delete</a></td>
                    </tr>',
                    $row->Name,
                    $row->duration,
                    $row->location, 
                    $row->description,
                    $row->ImageId,
                    $row->Name,
                    $row->Name,
                    );
                }
                else
                {
                    echo '
                    <div class="error">
                    Opps. Record not found.
                    [ <a href="adminEvent.php">Back to list</a> ]
                    </div>
                    ';

                    $hideForm = true; // Flag, "true" to hide the form.
                }

                $result->free();
                $con->close();
            }
            echo '</table>'
                


            ?>
            </div>
        </div>
    </body>
</html>