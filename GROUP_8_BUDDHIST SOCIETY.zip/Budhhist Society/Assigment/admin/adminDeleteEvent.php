<!--ONG ZHENG XIANG-->
<html>
    <head>
        <style>
            .container{
                background-color: #364125;
                width: 88%;
                margin-top: 20px;
                float: right;
                grid-row: 1 / span 2;
                height: 100%;
                padding: 10px;
            }
            
            table{
                background-color:#E2E8C0;
                border: 1px solid black;
                color: black;
                padding: 10px 10px;
                text-decoration: none;
                display: inline-block;
                font-size: 19px;
                margin: 4px 2px;
            }
            
            textarea{
                background-color:#E2E8C0;
                width: 100%;
                height: 150px;
                padding: 12px 20px;
                margin-bottom: 10px;
                box-sizing: border-box;
                border-radius: 4px;
                font-size: 16px;
                resize: none;
            }
            
            .editEvent{
                color: white;
            }
            
             input[type=submit], input[type=reset] {
                cursor: pointer;
            }
            
            .yes, .cancel{
                font-size: 16px;
                cursor: pointer;
                background-color:#E2E8C0;
                border: none;
                padding: 10px 10px;
                margin-left:3px;
            }
    </style>
        
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <?php
        session_start();
            include 'adminBackground.php'; 
            require_once('includes/database.php');
            require_once('includes/eventFunction_dbh.php'); 
        ?>
    </head>
    <body>
        <div class="container">
            <div class="editEvent">
                    <h2>Delete Event:</h2>
            <?php     
            if($_SERVER['REQUEST_METHOD'] == 'GET')
            {

                $name = ($_GET['name']);

                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $name  = $con->real_escape_string($name);
                $sql = "SELECT * FROM event WHERE Name = '$name'";

                $result = $con->query($sql);
                if ($row = $result->fetch_object())
                {
                    $name = $row->Name;
                    $duration  = $row->duration;
                    $location = $row->location;
                    $description = $row->description;
                    $ImageId = $row->ImageId;

                    printf('
                    <p>
                        Are you sure you want to delete the following Event?
                    </p>
                    <table border="1" cellpadding="6" cellspacing="0">
                        <tr>
                            <td>Name</td>
                            <td>%s</td>
                        </tr>
                        <tr>
                            <td>Duration</td>
                            <td>%s</td>
                        </tr>
                        <tr>
                            <td>Location</td>
                            <td>%s</td>
                        </tr>
                        <tr>
                            <td>Description</td>
                            <td>%s</td>
                        </tr>
                        <tr>
                            <td>Image Id</td>
                            <td>%s</td>
                        </tr>
                    </table>
                    <form action="" method="post">
                        <input type="hidden" name="name" value="%s" />
                        <input type="hidden" name="duration" value="%s" />
                        <input type="submit" class="yes" name="yes" value="Yes" />
                        <input type="button" class="cancel" value="Cancel"
                               onclick="location=\'adminEvent.php\'" />
                    </form>',
                    $name, $duration, $location, $description, $ImageId,
                    $name, $duration);

                }
                else
                {
                    echo '
                        <div class="error">
                        Opps. Record not found.
                        [ <a href="adminEvent.php">Back to list</a> ]
                        </div>
                        ';
                }
                $result->free();
                $con->close();
            }
            else
            {

                $name = trim($_POST['name']);
                $duration   = trim($_POST['duration']);

                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

                // SELECT * FROM
                // INSERT INTO
                // UPDATE TABLE
                // DELETE FROM

                $sql = '
                    DELETE FROM event
                    WHERE Name = ?
                ';
                $stm = $con->prepare($sql);
                $stm->bind_param('s', $name);
                $stm->execute();

                if ($stm->affected_rows > 0)
                {
                    printf('
                        <div class="info">
                        Event <strong>%s</strong> has been deleted. Please proceed to the
                        <a href="adminEvent.php" style="color:white;"> Event page.</a>
                        </div>',
                        $name);
                }
                else
                {
                    echo '
                        <div class="error">
                        Opps. Database issue. Record not deleted.
                        </div>
                        ';
                }

                $stm->close();
                $con->close();
            }

            ?>

            </div>  
        </div>
    </body>
    <footer>
        
    </footer>
</html>

