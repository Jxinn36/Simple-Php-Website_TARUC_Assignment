<!--LEE JIA XIN-->
<?php
session_start();
?>
<html>
    <head>
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <?php  include 'adminBackground.php'; ?>
        <style>
            <?php include 'adminProfileSetting.css'; ?>
        </style>

            <?php
              include 'includes/database.php';
              include 'includes/profileHelper.php';
              
              $hideForm = false;
              $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
              
            if ($_SERVER['REQUEST_METHOD'] == 'GET')
            {
                $username = ($_GET['name']);

                $username  = $con->real_escape_string($username);
                $sql = "SELECT * FROM users WHERE username = '$username'";

                $result = $con->query($sql);
                if ($row = $result->fetch_object())
                {
                    $username = $row->username;
                    $email  = $row->email;
                    $password = $row->password;
                }
                else
                {
                    echo '
                    <div class="error">
                    Opps. Record not found.
                    [ <a href="adminProfile.php">Back to list</a> ]
                    </div>
                    ';
                    $hideForm = true; // Flag, "true" to hide the form.
                }
                $result->free();
                $con->close();
            }
            if(isset($_POST['submit']))
            {
                $username = $_POST['name'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $confirmPassword = $_POST['confirmPassword'];

                $error['email']  = validateEmail($email);
                $error['password'] = validatePass($password);
                $error['confrimPassword'] = validatePass($password , $confirmPassword);
                $error = array_filter($error);
                    $password = md5($password);
                if (empty($error))
                {
                    $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                    $sql = "
                        UPDATE users SET
                        email = '$email', password = '$password'
                        WHERE username = '$username'
                    ";

                if(mysqli_query($con , $sql))
                {
                    printf('
                       <div class="info">
                       Event <strong>%s</strong> has been updated.
                       [ <a href="adminProfile.php">Back to list</a> ]
                       </div>',
                       $username);
                }
                else
                {
                    echo '
                    <div class="error">
                    Opps. Database issue. Record not updated.
                    </div>
                    ';
                }
                    $con->close();
            }
            else
            {
                // Validation failed. Display error message.
                echo '<ul class="error">';
                foreach ($error as $value)
                {
                    echo "<li>$value</li>";
                }
                echo '</ul>';
            }
        }
        // --> Retrieve Student record based on the passed StudentID.
    ?>
    </head>
    
    <body>
   
        <div class="container">
            <div class="editProfile">
                    <h2>Edit Profile:</h2>
                    <form action="" method="post" id="editProfile">
                        
                         <table cellpadding="5" cellspacing="0">
                            <tr>
                                <td><label for="id">Username :</label></td>
                                <td>
                                    <?php echo $username ?>
                                    <input type="hidden" name="name" value="<?php echo $username; ?>">
                                </td>
                            </tr>
                            <tr>
                                <td><label for="email">Email :</label></td>
                                <td>
                                    <input type="email" name="email" id="" value="<?php echo $email;?>">
                                </td>
                            </tr>
                            <tr>
                                <td><label for="password">Password :</label></td>
                                <td>
                                    <input type="password" name="password" id="" value="<?php echo $password;?>">
                                </td>
                            </tr>
                            <tr>
                                <td><label for="confirmPassword">Confirm Password :</label></td>
                                <td>
                                    <input type="password" name="confirmPassword" id="">
                                </td>
                            </tr>
                        </table>

                            <button type="submit" name="submit">Submit</button>
                     
                        <a href="adminProfileSetting.php"  type="reset" id="reset" value="reset" class="button1"><h1>Reset</h1></a>
               
                   </form>      
               </div>  
        </div>
    </body>

</html>