<!--ONG ZHENG XIANG-->
<?php
   include 'database.php';

//////////////////////////////////////////////Add Event   
if(isset($_POST['submit'])){

    // datasbase connection
    require_once 'database.php'; 
    $file = $_FILES['file'];
    $name = $_POST['name'];
    $duration  = $_POST['duration'];
    $location = $_POST['location'];
    $description = $_POST['description'];
    $err = '';
    
    if (empty($name) || empty($duration) || empty($location)|| empty($description)) // Something posted back.
    {
        header("Location: ../adminAddEvent.php?error=emptyFields");
        exit();
    }
    else if (strlen($name) > 500){
        header("Location: ../adminAddEvent.php?error=invalidName");
        exit();
    }
    else if (strlen($duration) > 100){
        header("Location: ../adminAddEvent.php?error=invalidDuration");
        exit();
    }
    else if (strlen($location) > 500){
        header("Location: ../adminAddEvent.php?error=invalidLocation");
        exit();
    }
    else if (!preg_match("/^[a-zA-Z0-9,. ]*$/",$location)){
        header("Location: ../adminAddEvent.php?error=invalidLocation");
        exit();
    }
    else if (strlen($description) > 1000){
        header("Location: ../adminAddEvent.php?error=invalidDescription");
        exit();
    }
    else if (isNameExist($name)) {
        header("Location: ../adminAddEvent.php?error=DuplicateEventName");
        exit();	
    }
    else if($file['error'] > 0){
        switch ($file['error'])
        {
            case UPLOAD_ERR_NO_FILE: // Code = 4.
                $err = 'No file was selected.';
                break;
            case UPLOAD_ERR_FORM_SIZE: // Code = 2.
                $err = 'File uploaded is too large. Maximum 1MB allowed.';
                break;
            default: // Other codes.
                $err = 'There was an error while uploading the file.';
                break;
        }
    }
    else if ($file['size'] > 2107152)
    {
        // Check the file size. Prevent hacks.
        // 1MB = 1024KB = 1048576B.
        $err = 'File uploaded is too large. Maximum 1MB allowed.';
    }
    else{
        //for img
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext != 'jpg'  && $ext != 'jpeg' && $ext != 'gif'  && $ext != 'png')
        {
            $err = 'Only JPG, GIF and PNG format are allowed.';
        }
        else {
            $save_as = uniqid() . '.' . $ext;
            move_uploaded_file($file['tmp_name'], '../../uploads/' . $save_as);
            // Save the file.
            $db = mysqli_connect("localhost", "root", "", "assignment");
            $sql = "INSERT INTO event (Name, duration, location, description, ImageId) VALUES("
                    . "'$name', '$duration','$location','$description', '$save_as') ";
            mysqli_query($db, $sql);

            $name = $duration = $location = $description = null;

            header("Location: ../adminAddEvent.php?error=signUp");
            exit();
            
            $con->close();
        }
        
        if ($err) {
            echo '<div class="error">' . $err . '</div>';
        }
    }
}
   
//////////////////////////////////////////////////////////////////////////////////
function isNameExist($name)
{
    $exists = false;
    $con = mysqli_connect('localhost', 'root', '', 'assignment');
    $name  = $con->real_escape_string($name);
    $sql = "SELECT * FROM event WHERE Name = '$name'";

    if ($result = $con->query($sql))
    {
        if ($result->num_rows > 0)
        {
            $exists = true;
        }
    }

    $result->free();
    $con->close();
    return $exists;
}
function htmlInputHidden($name, $value = '')
{
    printf('<input type="hidden" name="%s" id="%s" value="%s" />' . "\n",
               $name, $name, $value);
}
function htmlInputText($name, $value = '', $maxlength = '')
{
    printf('<input type="text" name="%s" id="%s" value="%s" maxlength="%s" />' . "\n",
           $name, $name, $value, $maxlength);
}

