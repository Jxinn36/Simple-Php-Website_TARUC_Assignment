<!--ONG ZHENG XIANG-->
<?php      
    include('database.php');
        
function isNameExist($name)
{
    $exists = false;
    $con = mysqli_connect('localhost', 'root', '', 'assignment');
    $name  = $con->real_escape_string($name);
    $sql = "SELECT * FROM event WHERE Name = '$name'";

    if ($result = $con->query($sql))
    {
        if ($result->num_rows > 0)
        {
            $exists = true;
        }
    }

    $result->free();
    $con->close();
    return $exists;
}

function htmlInputHidden($name, $value = '')
{
    printf('<input type="hidden" name="%s" id="%s" value="%s" />' . "\n",
       $name, $name, $value);
}

function htmlInputText($name, $value = '', $maxlength = '')
{
    printf('<input type="text" name="%s" id="%s" value="%s" maxlength="%s" />' . "\n", 
       $name, $name, $value, $maxlength);
}

function validateName($name)
{
    if ($name == null)
    {
        return 'Please enter <strong>Event Name</strong>.';
    }
    else if (strlen($name) > 30) // Prevent hacks.
    {
        return '<strong>Event Name</strong> must not more than 30 letters.';
    }
}

function validateDuration($duration)
{
    if ($duration == null)
    {
        return 'Please enter <strong>duration</strong>.';
    }
}

function validateLocation($location)
{
    if ($location == null)
    {
        return 'Please enter <strong>location</strong>.';
    }
}

function validateDescription($description)
{
    if ($description == null)
    {
        return 'Please enter <strong>description</strong>.';
    }
    else if (strlen($description) > 500) // Prevent hacks.
    {
        return '<strong>Description</strong> must not more than 500 letters.';
    }
}