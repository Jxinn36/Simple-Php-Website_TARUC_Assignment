<!--LEE JIA XIN-->

<?php
   include 'database.php';

function htmlInputHidden($username, $value = '')
{
    printf('<input type="hidden" name="%s" id="%s" value="%s" />' . "\n",
      $username, $username, $value);
}

function htmlInputText($username, $value = '', $maxlength = '')
{
    printf('<input type="text" name="%s" id="%s" value="%s" maxlength="%s" />' . "\n",
       $username, $username, $value, $maxlength);
}
