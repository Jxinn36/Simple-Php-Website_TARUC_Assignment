<!--LEE JIA XIN-->
<?php  SESSION_START() ?>
<html>
    <head>
        <style>
            <?php
                include 'adminEditMember.css'; 
            ?>
        </style>

        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
          <?php
        include 'adminBackground.php'; 
        require_once 'includes/database.php';
        
        if(isset($_REQUEST['name']))
        {
            $username = mysqli_real_escape_string($con , $_GET['name']);
            $email = $_GET['email'];
        }

        if(isset($_POST['update']))
        {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $sql = "update users set email = '$email' where username = '$username'";
            if(mysqli_query($con , $sql))
            {   
                printf('
                   <div class="info" style="color: white;">
                   Member <strong>%s</strong> has been updated.
                   [ <a href="adminMember.php">Back to list</a> ]
                   </div>',
                    $username);
            }
            else{
                echo "Database Problem, Please contact the system admin";
            }
        }  
        ?>
    </head>
    
    <body>
        <div class="container">
            <div class="editMember">
                    <h2>Edit Member:</h2>
                    <form method="post" action="" id="editMember">
                                 <table cellpadding="5" cellspacing="0">
                            <tr>
                                <td><label for="id">Name :</label></td>
                                <td>
                                    <?php echo $username ?>
                                    <input type="hidden" name="username" value="<?php echo $username?>">
                                    
                                </td>
                            </tr>
                            <tr>
                                <td><label for="email">Email :</label></td>
                                <td>
                                    <input type="email" name="email" id="" value="<?php echo $email?>">
                                </td>
                            </tr>
                            
                        </table>

                    
                       <br>
                       <input name = "update"type="submit" id="submit" value="submit" style="font-size:20px; padding-left: 55px; padding-right: 55px;">
                       <input type="reset" id="reset" value="reset" style="font-size:20px; padding-left: 52px; padding-right: 52px;">
                   </form>      
               </div>  
        </div>
    </body>
    <footer>
        
    </footer>
</html>