<!--LEE JIA XIN-->
<?php  SESSION_START() ?>
<?php // include('includes/functions.php') ?>

<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
         <meta name="viewport" content="width=device-width, initial-scale=1" />
         <?php include 'adminBackground.php'; ?> 
    <style>
    /* ===============================
                  Table 
       ===============================
    */
       .home{                       /*table space*/
         border-spacing: 50px; 
         width:80%;
         height: 100px;
         margin-left:auto;
          margin-right:auto;
       }

       .home p {                 
         font-size: 26px;           /*front size*/
         float:right;               /*front float*/
         margin: -50px 5px;         /*front margin*/
       }

        .home th{                   /*table design*/
          color: black;
          background-color: #EBEED2;
          text-align: left;
          border: 1px solid;
          padding:10px;
          box-shadow: 5px 10px #888888;
        }

    /* ===============================
              Mobile Devices
       ===============================
   */    
        @media screen and (max-width: 900px) {
         .home th{   
            width: 100%;
            margin:70px 5px;
            display: block;
            margin-bottom: 20px;
          }

        }
    </style>
  </head>
    
  <body>
    
      <table class="home">      
        <tr>
           <?php require_once 'includes/database.php';
              $query = "SELECT Name FROM event ORDER BY Name";
              $query_run = mysqli_query($con,$query);
              $eventRow = mysqli_num_rows($query_run); 
            ?>
            <th><h1>&#127895; Event</h1><?php echo '<p>'.$eventRow.'</p> '?></th>
             
           <?php require_once 'includes/database.php';
              $query = "SELECT BookingID FROM bookings ORDER BY BookingID";
              $query_run = mysqli_query($con,$query);
              $bookingRow = mysqli_num_rows($query_run);
            ?>
             
            <th><h1>&#128391; Booking</h1><?php echo '<p>'.$bookingRow.'</p> '?></th> 
        </tr>
        
        <tr>
            <?php require_once 'includes/database.php';
               $query = "SELECT user_type FROM users  WHERE user_type = 'admin'";
               $query_run = mysqli_query($con,$query);
               $adminRow = mysqli_num_rows($query_run);
            ?>
            <th><h1> &#9939; Admin</h1><?php echo '<p>'.$adminRow.'</p> '?></th>
             
            <?php require_once 'includes/database.php';
               $query = "SELECT user_type FROM users WHERE user_type = 'user'";
               $query_run = mysqli_query($con,$query);
               $userRow = mysqli_num_rows($query_run);
            ?>
            <th><h1> &#128444; User</h1><?php echo '<p>'.$userRow.'</p> '?></th>  
          </tr> 
       </table>
  
  </body>
</html>