<!--ONG ZHENG XIANG-->
<?php
session_start();
    include 'adminBackground.php';
    include 'includes\database.php';
    
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=8" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <title>Upload Image</title>
        <style><?php    include 'adminAddEvent.css';?> </style>
    </head>
    <body>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'GET')
        {
            $name = ($_GET['name']);
            $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
            $name  = $con->real_escape_string($name);
            $sql = "SELECT * FROM event WHERE Name = '$name'";

            $result = $con->query($sql);
            if ($row = $result->fetch_object())
            {
                $image = $row->ImageId;
            
            }
            else
            {
                echo '
                <div class="error">
                Opps. Record not found.
                [ <a href="adminEvent.php">Back to list</a> ]
                </div>
                ';

                $hideForm = true; // Flag, "true" to hide the form.
            }

            $result->free();
            $con->close();
        }
        
        
        if (isset($_POST['delete']) || isset($_POST['updateImg']))
        {
            $image = $_POST['image'];
            $path = "../uploads/$image";
            
            if($image != ""){    
                unlink($path);
            }
            if(isset($_POST['updateImg'])){
                //upload file
                $file = $_FILES['file'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

                // Check the file extension.
                if ($ext != 'jpg'  &&
                    $ext != 'jpeg' &&
                    $ext != 'gif'  &&
                    $ext != 'png')
                {
                    $err = 'Only JPG, GIF and PNG format are allowed.';
                }else
                {
                
                $save_as = uniqid() . '.' . $ext;
                move_uploaded_file($file['tmp_name'], '../uploads/' . $save_as);
                
                //create sql statement
                $sql = " 
                    UPDATE event SET ImageId = ? WHERE ImageId = ?
                ";
                $stm = $con->prepare($sql);
                $stm->bind_param('ss', $save_as, $image);
                $stm->execute();
                
                $stm->close();
                $con->close();
                $image = $save_as;
                } 
            }
            else{
            $sql = " 
                    UPDATE event SET ImageId = '' WHERE ImageId = ?
                ";
                $stm = $con->prepare($sql);
                $stm->bind_param('s', $image);
                $stm->execute();

                if ($stm->affected_rows > 0)
                {
                    printf('
                        <div class="info">
                        Image <strong>%s</strong> has been deleted. Please proceed to the
                        <a href="adminAddEventPic.php" style="color:white;"> Event page.</a>
                        </div>',
                        $image);
                }
                else
                {  
                    echo '
                        <div class="error">
                        dddsdasd Opps. Database issue. Record not deleted. 
                        </div>
                        ';
                    printf('<div class="error">%s</div>', $name);                   
                }
                $stm->close();
                $con->close();
            }
        }
        ?>

        <br />
        <div class="container">
            <div class="addEvent">
                <h1>Upload Image</h1>
                <?php 
                printf(
                    '<div><img class="eventImg" src = "../uploads/%s" style="width: 200px;"></div>',
                    $image); 
                printf('
                <form action="%s" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="image" value="%s" />
                    <input type="hidden" name="MAX_FILE_SIZE" value="1048576" />
                    <input type="file" name="file" style="font-size: 16px;" id="file" accept=".gif, .jpg, .jpeg, .png" /><br />
                    <input type="submit" name="delete" value="Delete" />
                    <input type="submit" name="updateImg" value="Update" />
                </form>', $_SERVER['PHP_SELF'] ,$image);
                ?>
            </div>
        </div>
        
    </body>
</html>

