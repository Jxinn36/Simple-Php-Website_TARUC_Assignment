<!--EER SHIAN WEI-->
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php session_start(); ?>
        <?php include 'adminBackground.php'; ?> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <style>
        
        /* ===============================
                      Body
           ===============================
        */ 
        .container{
           background-color: #364125;
           color: white;
           width: 88%;
           margin-top: 20px;
           float: right;
           grid-row: 1 / span 2;
           height: auto;
           padding: 10px;
        }

        /* ===============================
                      Table
           ===============================
        */ 
        table, td, th {
           border: 1px solid black;
           text-align: center;
           margin-bottom: 20px;
        }

        th{
           background-color: #E2E8C0;
           font-size: 20px;
           padding: 5px 5px;
        }

        table {
           width: 100%;
           border-collapse: collapse;
           background-color: white;
           align-content: center;
        }

        .head{
            background-color: #E2E8C0;
            font-size: 24px;
            width: 20%;
            text-align: left;
            padding: 5px;
        }

        .content{
            font-size: 24px;
            width: 80%;
            text-align: left;
            padding: 5px;
        }
        
       
        /* ===============================
                      Link
           ===============================
        */           
        .info a{
            background-color:#364125;
            color: white;
        }
            
        .info a:hover{
            background-color:#364125;
            color: red;
        }
        
        /* ===============================
                      Button
           ===============================
        */  
        .yes, .cancel{
            font-size: 16px;
            cursor: pointer;
            background-color:#E2E8C0;
            border: none;
            padding: 10px 10px;
            margin-left:3px;
        }
            
        /* ===============================
                     Mobile View
           ===============================
         */ 
        @media only screen and (max-width: 760px), (min-device-width: 768px) and (max-device-width: 1024px) {     
           .container {   
                width:100%;
                margin: 80px 0px 0px 0px;
            }

           .editButton,#reset{
               padding: 10px 20px;
               text-decoration: none;
               margin: 4px 2px;
               cursor: pointer;
               font-size:12px; 
               font-family: sans-serif;
            }
        }
    </style>
 <body>
        
        <div class="container">
        <h1>Delete Booking</h1>
            <?php
            require_once('includes/shianWei_helper.php');
            if($_SERVER['REQUEST_METHOD'] == 'GET'){
                $id = strtoupper(trim($_GET['id']));

                $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                $id = $con->real_escape_string($id);
                $sql = "SELECT * FROM Bookings WHERE BookingID = '$id'";

                $result = $con->query($sql);
                if($row = $result->fetch_object()){
                    $id = $row->BookingID;
                    $eventName = $row->EventName;
                    $eventDuration = $row->EventDuration;
                    $eventLocation = $row->EventLocation;
                    $participantName = $row->ParticipantName;
                    $status = $row->Status;

                    printf('
                        <p>Are you sure you want to delete the following booking?</p>
                        <table>
                            <tr>
                                <td class="head">Booking ID: </td>
                                <td class="content">%s</td>
                            </tr>
                            <tr>
                                <td class="head">Event Name: </td>
                                <td class="content">%s</td>
                            </tr>
                            <tr>
                                <td class="head">Event Duration: </td>
                                <td class="content">%s</td>
                            </tr>
                            <tr>
                                <td class="head">Event Location: </td>
                                <td class="content">%s</td>
                            </tr>
                            <tr>
                                <td class="head">Participant Name: </td>
                                <td class="content">%s</td>
                            </tr>
                            <tr>
                                <td class="head">Status: </td>
                                <td class="content">%s</td>
                            </tr>
                        </table>
                        <form action="" method="post">
                            <input type="hidden" name="id" value="%s" />
                            <input type="submit" class="yes" name="yes" value="Yes" />
                            <input type="button" class="cancel" value="Cancel" onclick="location=\'adminBooking.php?sort=BookingID&order=AS\'" />
                        </form>', 
                        $id, $eventName, $eventDuration, $eventLocation, $participantName, $status, $id);
                }
                else{
                    echo '
                        <div class="error">
                        Booking not found.
                        [ <a href="adminBooking.php?sort=BookingID&order=AS">Back to list.</a> ]
                        </div>
                        ';
                }
                $result->free();
                $con->close();
            }
            else{
                $id = strtoupper(trim($_POST['id']));

                $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

                $sql = '
                    DELETE FROM Bookings WHERE BookingID = ?
                ';
                $stm = $con->prepare($sql);
                $stm->bind_param('s', $id);
                $stm->execute();
                if($stm->affected_rows > 0){
                    printf('
                        <div class="info">
                        Booking has been deleted.
                        [ <a href="adminBooking.php?sort=BookingID&order=ASC">Back to list</a> ]
                        </div>'
                    );
                }
                else{
                    echo '
                    <div class="error">
                    Database issue. Booking not deleted.
                    </div>
                    ';
                }
                $stm->close();
                $con->close();
            }
            ?>
        </div>
    </body>
</html>