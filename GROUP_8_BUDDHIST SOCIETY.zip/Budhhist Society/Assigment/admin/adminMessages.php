<!--EER SHIAN WEI-->
<html>
    <head>
        <meta  charset="UTF-8">
        <title>TARC Buddhist Society</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php session_start(); ?>
        <?php include 'adminBackground.php'; ?> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <style>
        <?php include 'adminMessages.css'; ?> 
    </style>
    <body>
        <div class="container">
            <h1>Messages</h1>
            <form action="" method="post">
            <?php
            require_once('includes/helper.php');

            if(isset($_POST['delete'])){
                $checked = $_POST['checked'];
                if(!empty($checked)){
                    $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                    foreach ($checked as $value){
                        $escaped[] = $con->real_escape_string($value);
                    }
                    $sql = "DELETE FROM Messages WHERE MessageID IN ('" .
                            implode("','", $escaped) . "')";
       
                    if($con->query($sql)){
                        printf('
                            <div class="info">
                            <strong>%d</strong> messages(s) has been deleted.
                            </div>', 
                            $con->affected_rows);
                    }
                    $con->close();
                }
            }

            $headers = array(
                'MessageID' => 'Message ID',
                'ParticipantName' => 'Name',
                'ParticipantEmail' => 'Email',
                'MessageSubject' => 'Subject',
                'MessageDescription' => 'Description',              
            );

            echo '<table class="content">';
            echo '<tr>';
            echo '<th>&nbsp;</th>';

            foreach ($headers as $key => $value){
                printf('<th>%s</th>', $value);
            }

            echo '<th>&nbsp;</th>';
            echo '</tr>';

           $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
            $sql = "SELECT * FROM Messages WHERE MessageID";
              
                if($result = $con->query($sql)){
                    while($row = $result->fetch_object()){
                        printf('
                            <tr>
                            <td>
                                <input type="checkbox" name="checked[]" value="%s"/>
                            </td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>
                                <a href="adminDeleteMessage.php?id=%s">Delete</a>
                            </td>
                            </tr>',
                            $row->MessageID,
                            $row->MessageID,
                            $row->ParticipantName,
                            $row->ParticipantEmail,
                            $row->MessageSubject,
                            $row->MessageDescription,
                            $row->MessageID,
                        );
                    }
                }
                printf('
                    <tr>
                    <td colspan="10">
                        %d messages(s) returned.
                    </td>
                    </tr>',
                    $result->num_rows
                );
                echo '</table>';
                $result->free();
                $con->close();
            ?>
            <br/>
            <input type="submit" name="delete" class="delete" value="Delete Checked"
                onclick="return confirm('This will delete all checked messages.\nAre you sure?')" />
            </form>  
        </div>
    </body>
</html>