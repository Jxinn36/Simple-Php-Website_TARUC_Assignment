<!--LEE JIA XIN-->
<!DOCTYPE html>
<html>
<head> 
     <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society Admin</title>
<style>
    
* {
  box-sizing: border-box;
}

/* ===============================
	  Header &Body
   ===============================
*/
body {
  padding: 5px;
  background: #E2E2DF;
}

.header {
  padding: 5px;
  text-align: center;
}

.header h1 {
  font-size: 50px;
}

 .topnav img{ 
    border-radius: 50%;           /*round image*/
 }  
 
 /* ===============================
	  Top bar & Side bar
   ===============================
*/
.topnav {                          /* Style of top bar */
  overflow: hidden;
  background-color: #364125;
}

.topnav a {            /* Style of top bar & side bar links */
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: left;
  padding: 14px 16px;
  text-decoration: none;
}
.main{
   grid-template-columns: 1fr 1fr;
}

.sideNav{
   grid-column: 1 / span 2;
   float: left;
   width: 0%;
   height: 100%;
}

.sideNav a{
   display: block;
   color: #f2f2f2;
   text-align: left;
   padding: 14px 16px;
   text-decoration: none;
}

.sideNav a:hover {                 /* side bar color hover color */
  background-color: #ddd;
  color: black;
  width: 100%;
}

nav > ul {                        /* style of side bar */
   list-style-type: none;
   padding-left: 5px;
   width:130px;
}

nav > ul > li{                  /* style of side bar lists */
   background-color:#364125;
   height: 100px;
}

a#navicon {
   display: none;
}
   
/* ===============================
     Mobile Devices: 0 to 480px 
   ===============================
*/
@media screen and (max-width: 400px) {
  .topnav  {
    float: none;
    width: 100%;
  }
  
  .main {
    float: none;
    width: 100%;
  }
}

@media only screen and (max-width: 900px) {

    nav ul  {
      font-size: 1em;
      line-height: 1.3em;
      height: 2.3em;
      display: -webkit-flex;
      display: flex;
      -webkit-flex-flow: column wrap;
      flex-flow: column wrap;
      width:460px;

   }
}
</style>
</head>

<body>
    <div class="header">
      <h1>TARC Buddhist Society Admin</h1>
    </div>
    <?php
        if($_SESSION['admin']){
            ?>
          <div class="topnav">
        <a id="navicon" href="#"><img src="images/nav icon.png" width=100% alt="" /></a>
      <a style="float:right">Welcome <?php echo $_SESSION['admin']['username']; ?> !<img  src = "images/user profile.jpeg" height=30px width=30px></a>
    </div>
          <?php
        }?>

    <div class="main">
        <div class="sideNav">
            <nav>
                <ul> 
                    <li><a href="adminHomePage.php">Home</a></li>
                    <li><a href="adminProfile.php">Admin</a></li>
                    <li><a href="adminMember.php">Member</a></li>
                    
                        <li><a href="adminEvent.php">Events</a></li>
   
                    <li><a href="adminBooking.php?sort=BookingID&order=ASC">Booking</a></li>
                     <li><a href="adminMessages.php">Messages</a></li>
                </ul>
            </nav>
        </div>
    </div>    


 
          

  </body>
</html>