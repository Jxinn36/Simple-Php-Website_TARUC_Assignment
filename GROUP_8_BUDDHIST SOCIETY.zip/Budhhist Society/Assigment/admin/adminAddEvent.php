<!--ONG ZHENG XIANG-->
<?php
    session_start();
    include 'adminBackground.php';
?>
<html>
    <head>
        <style><?php include 'adminAddEvent.css';?> </style>
 
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            p{
                color: black;
            }
        </style>
    <div class="error">
        <?php
        
        if(isset($_GET["error"])){
            if($_GET["error"] == "emptyFields"){
                echo"<p>Please fill in all fields!</p>";
            }
            else if($_GET["error"] == "invalidName"){
                echo"<p>Name only allowed 100 characters</p>";
            }
            else if($_GET["error"] == "invalidDuration"){
                echo"<p>Duration only allowed 100 characters</p>";
            }
            else if($_GET["error"] == "invalidLocation"){
                echo"<p>Location only allowed 100 characters with no special characters</p>";
            }
            else if($_GET["error"] == "invalidDescription"){
                echo"<p>Description only allowed 500 characters</p>";
            }
            else if($_GET["error"] == "signUp"){
                printf('<p>Congrats! The event has been added, please proceed back to the <a class= "back" href="adminEvent.php"> Event page.</a> </p>');
            }
            else if($_GET["error"] == "DuplicateEventName"){
                printf('<p>Event name taken</a> </p>');
            }
            else{
                echo '<ul class="error">';
                foreach ($error as $value){
                    echo "<li>$value</li>";
                }
                echo '</ul>';
            }
        }
        ?>
    </div>
    </head>
    <body>
        <div class="container">
            <div class="addEvent">
                <div class="error">
                </div>
                    <h2>Add Event:</h2>
                    <form method="post" action="includes/eventFunction_dbh.php" enctype="multipart/form-data">
                        <label>Event Name</label><br>
                        <input type="text" id="name" name="name" maxlength="500" placeholder="10th anniversary" style="width: 100%;" required="required"><br>
                        <label>Duration</label><br>
                        <input type="text" id="duration" name="duration" maxlength="100" placeholder="12pm-2pm" style="width: 100%;" required="required"><br>
                        <label>location</label><br>
                        <input type="text" id="location" name="location" maxlength="500" placeholder="Tarc College" style="width: 100%;" required="required"><br>
                        <label>Description</label><br>
                        <textarea id="description" name="description" placeholder="write something" required="required"></textarea>
                        <br>
                        <input type="hidden" name="MAX_FILE_SIZE" value="1048576" />
                        <input type="file" name="file" style="font-size: 16px;" id="file" accept=".gif, .jpg, .jpeg, .png" /><br />
                        <button type="submit" name="submit" id="submit" value="submit" class="button">submit</button>
                        <button type="reset" name="reset" id="reset" value="reset" class="button" style="padding-right: 55px">reset</button>
                   </form>      
               </div>  
        </div>
    </body>
    <footer>
        
    </footer>
</html>

