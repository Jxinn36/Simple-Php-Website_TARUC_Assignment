<!--EER SHIAN WEI-->
<head>
    <?php
    $PAGE_TITLE = 'Edit Booking';
    session_start();
    include('adminBackground.php');
    ?>
</head>
<style>
        
        /* ===============================
                      Body
           ===============================
        */ 
        .container{
           background-color: #364125;
           color: white;
           width: 88%;
           margin-top: 20px;
           float: right;
           grid-row: 1 / span 2;
           height: auto;
           padding: 10px;
        }

        /* ===============================
                      Table
           ===============================
        */ 
        .content{
            text-align: left;
            width: 100%;
            font-size: 20px;
            border-collapse: collapse;
        }

        .content th{
            text-align: center;
        }

        .content tr:nth-of-type(odd){              /*ood number row have diiferent colour*/
            background: #ccc;
        }

        .content th, .content td{
            border: 2px solid black;
            height: 50px;
        }

        table, td, th {
           border: 1px solid black;
           text-align: center;
           margin-bottom: 20px;
        }

        th{
           background-color: #E2E8C0;
           font-size: 20px;
           padding: 5px 5px;
        }

        table {
           width: 60%;
           border-collapse: collapse;
           background-color: white;
           align-content: center;
        }
        /* ===============================
                    Button
           ===============================
        */ 
        .addParticipant button{
            font-size: 17px;
            padding: 6px 10px;
            margin-top: 8px;
            margin-right: 16px;
            width: 150px;
        }
        .button{
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 10px;
            cursor: pointer;
        }

        .button:link, .button:visited {
            background-color:#CFD897;
            color: black;
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: block;
            margin: auto;
        }

        .button:hover, .button:active {
            background-color: #E2E8C0;
            color: black;
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }

        .button:link {
            text-decoration: none;
            color: black;
        }

        .button:visited {
            text-decoration: none;
        }
        
        .update, .cancel{
            font-size: 16px;
            cursor: pointer;
            background-color:#E2E8C0;
            border: none;
            padding: 10px 10px;
            margin-left:3px;
        }
            
                .info a
             {
                background-color:#364125;
                color: white;
            }
            
               .info a:hover
             {
                background-color:#364125;
                color: red;
            }
        
    </style>
<body>
    <div class="container">
        <h1>Edit Booking</h1>
        <?php
        require_once('includes/shianWei_helper.php');
        
        $hideForm = false;
        
        if ($_SERVER['REQUEST_METHOD'] == 'GET')
        {
            $id = strtoupper(trim($_GET['id']));

            $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $id  = $con->real_escape_string($id); 
            $sql = "SELECT * FROM Bookings WHERE BookingID = '$id'";

            $result = $con->query($sql);
            if ($row = $result->fetch_object())
            {
                $id = $row->BookingID;
                $eventName      = $row->EventName;
                $eventDuration    = $row->EventDuration;
                $eventLocation  = $row->EventLocation;
                $participantName = $row->ParticipantName;
                $status = $row->Status;
            }
            else
            {
                echo '
                    <div class="error">
                    Opps. Record not found.
                    [ <a href="adminBooking.php">Back to list</a> ]
                    </div>
                    ';

                $hideForm = true;
            }

            $result->free();
            $con->close();
        }

        else
        {
            $id      = strtoupper(trim($_POST['BookingID']));
            $eventName      = trim($_POST['EventName']);
            $eventDuration    = trim($_POST['EventDuration']);
            $eventLocation  = trim($_POST['EventLocation']);
            $participantName = trim($_POST['ParticipantName']);
            $status = trim($_POST['Status']);

            // Validations:
            $error['Status']  = validateStatus($status);
            $error = array_filter($error);

            if (empty($error))
            {
                $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                $sql = '
                    UPDATE Bookings SET
                    Status = ?
                    WHERE BookingID = ?
                ';
                $stm = $con->prepare($sql);
                $stm->bind_param('ss', $status, $id);

                if($stm->execute())
                {
                    printf('
                        <div class="info">
                        Booking <strong>%s</strong> has been updated.
                        [ <a href="adminBooking.php?sort=BookingID&order=AS">Back to list</a> ]
                        </div>',
                        $id);
                }
                else
                {
                    echo '
                        <div class="error">
                        Opps. Database issue. Record not updated.
                        </div>
                        ';
                }
                $stm->close();
                $con->close();
            }
            else
            {
                // Validation failed. Display error message.
                echo '<ul class="error">';
                foreach ($error as $value)
                {
                    echo "<li>$value</li>";
                }
                echo '</ul>';
            }
        }
        ?>
        <?php if ($hideForm == false) : // Hide or show the form.  ?>
        
        <form action="" method="post">
            <table class="content">
                <tr>
                    <td><label for="id">Booking ID: </label></td>
                    <td>
                        <?php echo $id ?>
                        <?php htmlInputHidden('BookingID',$id)?>
                </tr>
                <tr>
                    <td><label for="eventName">Event :</label></td>
                    <td>
                        <?php echo $eventName ?>
                        <?php htmlInputHidden('EventName', $eventName)?>
                    </td>
                </tr>
                <tr>
                    <td><label for="eventDuration">Event Duration:</label></td>
                    <td>
                        <?php echo $eventDuration ?>
                        <?php htmlInputHidden('EventDuration', $eventDuration)?>
                    </td>
                </tr>
                <tr>
                    <td><label for="eventLocation">Event Location:</label></td>
                    <td>
                        <?php echo $eventLocation ?>
                        <?php htmlInputHidden('EventLocation', $eventLocation)?>
                    </td>
                </tr>
                <tr>
                    <td><label for="participantName">Participant Name :</label></td>
                    <td>
                        <?php echo $participantName ?>
                        <?php htmlInputHidden('ParticipantName', $participantName)?>
                    </td>
                </tr>
                <tr>
                    <td>Status :</td>
                    <td>
                        <?php htmlRadioList('Status', $STATUS, $status) ?>
                    </td>
                </tr>
            </table>
            <br />
            <input type="submit" class="update" name="update" value="Update" />
            <input type="button" class="cancel" value="Cancel" onclick="location='adminBooking.php?sort=BookingID&order=AS'" />
        </form>
        <?php endif ?>
    </div>
</body>