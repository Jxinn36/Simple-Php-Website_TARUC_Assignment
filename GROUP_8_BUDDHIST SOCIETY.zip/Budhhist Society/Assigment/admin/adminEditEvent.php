<!--ONG ZHENG XIANG-->
<?php
$PAGE_TITLE = 'Edit Event';
?>
<html>
    <head>
        <style>
           <?php
             include 'adminEditEvent.css'; 
           ?>
       </style>
        
        <meta  charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>TARC Buddhist Society</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <?php
        session_start();
        include 'adminBackground.php'; 
        require_once 'includes/database.php';
        require_once 'includes/helper.php';
        
        $hideForm = false;
        if ($_SERVER['REQUEST_METHOD'] == 'GET')
        {
            $name = ($_GET['name']);

            $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
            $name  = $con->real_escape_string($name);
            $sql = "SELECT * FROM event WHERE Name = '$name'";

            $result = $con->query($sql);
            if ($row = $result->fetch_object())
            {
                $name = $row->Name;
                $duration  = $row->duration;
                $location = $row->location;
                $description = $row->description;
                $file = $row->ImageId;
            }
            else
            {
                echo '
                <div class="error">
                Opps. Record not found.
                [ <a href="adminEvent.php">Back to list</a> ]
                </div>
                ';

                $hideForm = true; // Flag, "true" to hide the form.
            }

            $result->free();
            $con->close();
        }
        else
        {
            $name = $_POST['name'];
            $duration  = $_POST['duration'];
            $location = $_POST['location'];
            $description = $_POST['description'];

            $error['name']    = validateName($name);
            $error['duration']  = validateDuration($duration);
            $error['location'] = validateLocation($location);
            $error['description'] = validateDescription($description);
            $error = array_filter($error);
            if (empty($error))
            {
                $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                $sql = '
                    UPDATE Event SET
                    duration = ?, location = ?, description = ?
                    WHERE Name = ?
                ';
                $stm = $con->prepare($sql);
                $stm->bind_param('ssss', $duration, $location, $description, $name);

                if($stm->execute())
                {
                        printf('
                            <div class="info">
                            Event <strong>%s</strong> has been updated.
                            [ <a  href="adminEvent.php">Back to list</a> ]
                            </div>',
                            $name);
                }
                else
                {
                    echo '
                    <div class="error">
                    Opps. Database issue. Record not updated.
                    </div>
                    ';
                }

                    $stm->close();
                    $con->close();
            }
            else
            {
                // Validation failed. Display error message.
                echo '<ul class="error">';
                foreach ($error as $value)
                {
                    echo "<li>$value</li>";
                }
                echo '</ul>';
            }


        }
        // --> Retrieve Student record based on the passed StudentID.

        
        ?>
    </head>
    <body>
        <div class="container">
            <div class="editEvent">
                    <h2>Edit Event:</h2>
                    <form method="post" action="" id="editEvent">
                       <table cellpadding="5" cellspacing="0">
                            <tr>
                                <td><label for="id">Event name :</label></td>
                                <td>
                                    <?php echo $name ?>
                                    <?php htmlInputHidden('name', $name) // Hidden field. ?>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="duration">Duration :</label></td>
                                <td>
                                    <?php htmlInputText('duration', $duration, 100) ?>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="location">Location :</label></td>
                                <td>
                                    <?php htmlInputText('location', $location, 100) ?>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="description">Description :</label></td>
                                <td>
                                    <?php htmlInputText('description', $description, 1000) ?>
                                </td>
                            </tr>

                        </table>
                        <br />
                       <button type="submit" name="update" id="submit" value="update" class="button">update</button>
                       <button type="reset" name="reset" id="reset" value="reset" class="button" style="padding-right: 55px">reset</button>
                   </form>      
               </div>  
        </div>
    </body>
    <footer>
        
    </footer>
</html>



